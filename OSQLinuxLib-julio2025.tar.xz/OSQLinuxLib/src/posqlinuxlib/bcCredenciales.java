// Proyecto   : OSQLinuxLib
// Paquete    : posqlinuxlib
// Módulo     : bcCredenciales.java
// Autor      : Octulio Biletán.
// Descripción: Definir la clase bcCredenciales.
//              Leer la documentación técnica doc-técnica.txt para más info.
// Fecha Ver. : Enero de 2025.
// Obs.       : OpenJDK 16, NetBeans IDE 23, OLS r7.9
// Licencia   : GNU GPL ver. 3

/* bcCredenciales.java
 *
 * Copyright (C) 2025 Eugenio Martínez.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Authors: Eugenio Martínez, https://t.me/octulioBiletan
 */

package posqlinuxlib;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;
import pConsola.ConsolaVirtual;

/** <b>OSQLinuxLib.jar</b><br>
 * Clase bcCredenciales.
 * @author Octulio Biletan
 */
public class bcCredenciales
{
    private boolean estado_error;       // Indicador de error de E/S
    private String msj_error;           // Ultimo mensaje de error de E/S.
    private String estadoOperativo;	// Estado operativo de la aplicación: no definido/activo/inactivo
    private String nm_fic_credenciales; // Nombre completo del fichero con extensión .properties
    private ConsolaVirtual vconsola;    // Consola virtual local para uso interno

    /**
     * Primer constructor de la clase.<br>
     * Inicializa los datos de la clase.
     */
    public bcCredenciales()
    {
        estado_error = false;
        msj_error = "<sin error>";
        nm_fic_credenciales = "";
        estadoOperativo = "no definido";
        vconsola = new ConsolaVirtual();
    }

    /**
     * Abre el fichero mencionado en 'nfic' para las operaciones de E/S.
     * @param nfic
     */
    public void abrir(String nfic)
    {
        String campo_estado = "";
        Properties propiedades = new Properties();

        vconsola.abrir();

        if(nfic.equals(nm_fic_credenciales))
        {
            vconsola.consolaVirtual().println("Aviso: el archivo ya se encuentra abierto.");
            msj_error = vconsola.textoSalida();
            estado_error = true;
            vconsola.cerrar();
            return;
        }

        if(!nfic.contains(".properties".toLowerCase()))
        {
            // Se agrega la extensión válida al final del nombre del fichero.
            nfic = nfic + ".properties";
        }

        nm_fic_credenciales = nfic;

        if(existeFichero(nm_fic_credenciales))
        {
            try
            {
                propiedades.load(new FileInputStream(nm_fic_credenciales));

                for(String campo : propiedades.stringPropertyNames())
                {
                    String valor = propiedades.getProperty(campo);

                    if(campo.equalsIgnoreCase("estado") == true)
                    {
                        campo_estado = valor;
                        break;
                    }
                }

                estado_error = false;
            }
            catch(IOException error)
            {
                vconsola.consolaVirtual().println("Error: " + error.getMessage());
                estado_error = true;
            }
        }
        else
        {
            estadoOperativo = "no definido";
            vconsola.cerrar();
            return;
        }

        estadoOperativo = campo_estado;
        msj_error = vconsola.textoSalida();
        vconsola.cerrar();
    }

    /**
     * Cierra las operaciones de E/S sobre el fichero vigente de las credenciales.
     */
    public void cerrar()
    {
        estado_error = false;
        msj_error = "<sin error>";
        nm_fic_credenciales = "";
        estadoOperativo = "no definido";
        vconsola.cerrar();
    }

    /**
     * Lee el 'item' perteneciente al fichero de las credenciales.<br>
     * Y devuelve el dato encontrado en 'item[0]'.<br>
     * Cada item del fichero está organizado así: "item = dato".<br><br>
     * <b>Ejemplo:</b><br>
     * <code>String []dato = new String[1];<br>
     * dato[0] = "servidor";<br>
     * credenciales.leer(dato);<br>
     * System.out.println(dato[0]);</code><br>
     * 
     * @param item es el nombre del item a leer, es de tipo String.
     * @return Devuelve 0 (correcto) o 1 (error).
     */
    public int leer(String []item)
    {
        int estado = 0;
        Properties propiedades = new Properties();

        vconsola.abrir();

        try {
            propiedades.load(new FileInputStream(nm_fic_credenciales));

            for (String campo : propiedades.stringPropertyNames()) {
                String valor = propiedades.getProperty(campo);

                if (campo.equalsIgnoreCase(item[0]) == true) {
                    item[0] = valor;  // dato encontrado
                    break;
                }
            }

            estado_error = false;
        } catch (IOException error) {
                vconsola.consolaVirtual().println("Error: " + error.getMessage());
                estado_error = true;
                estado = 1;
        }

        msj_error = vconsola.textoSalida();
        vconsola.cerrar();

        return estado;
    }

    /**
     * Lee el 'item' pertenciente al fichero de las credenciales.<br>
     * Cada item del fichero está organizado así: "item = dato".<br>
     * @param item es el nombre del item a leer, es de tipo String.
     * @return Devuelve el nombre del controlador JDBC (tipo enum).
     */
    public nombreCtrlJDBC leer(String item)
    {
        nombreCtrlJDBC conec = nombreCtrlJDBC.indefinido;
        Properties propiedades = new Properties();

        vconsola.abrir();

        try {
            propiedades.load(new FileInputStream(nm_fic_credenciales));

            for (String campo : propiedades.stringPropertyNames()) {
                String valor = propiedades.getProperty(campo);

                if(campo.equalsIgnoreCase(item) == true) {
                    conec = nombreCtrlJDBC.valueOf(valor);  // dato encontrado
                    break;
                }
            }

            estado_error = false;
        } catch (IOException error) {
                vconsola.consolaVirtual().println("Error: " + error.getMessage());
                estado_error = true;
        }

        msj_error = vconsola.textoSalida();
        vconsola.cerrar();

        return conec;
    }

    // 
    /**
     * Devuelve<br> true: hay error.<br>
     *          false: no hay error.
     * @return true o false.
     */
    public boolean hayError()
    {
        return estado_error;
    }

    /**
     * Devuelve el último mensaje de error que se registró.
     * @return El mensaje de error.
     */
    public String leerError()
    {
        return msj_error;
    }

    /**
     * Devuelve la condición operativa de la aplicación.<br>
     *
     * @return "no definido", "activo" o "inactivo"
     */
    public String condicionOperativa()
    {
	return estadoOperativo;
    }

    /**
     * Determina si el archivo 'fic' existe o no en el sistema de archivos.
     * @param fic Nombre completo del fichero a examinar si existe en el sistema de archivos.
     * @return 'true' existe el fichero sino 'false'.
     */
    public boolean existeFichero(String fic)
    {
        boolean estado;

        Path path = Paths.get(fic);
        estado = Files.isRegularFile(path, LinkOption.NOFOLLOW_LINKS);
        if(estado == false)
        {
            msj_error = "No se encuentra el archivo o no es un archivo regular.";
            estado_error = true;
        }

        return estado;
    }

    /**
     * Devuelve el nombre completo del archivo de las credenciales.
     * @return El nombre completo del archivo de las credenciales.
     */
    public String nombre()
    {
        return nm_fic_credenciales;
    }
}
