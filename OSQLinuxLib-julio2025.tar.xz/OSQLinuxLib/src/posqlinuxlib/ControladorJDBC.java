// Proyecto   : OSQLinuxLib
// Paquete    : posqlinuxlib
// Módulo     : ControladorJDBC.java
// Autor      : Octulio Biletán - Octubre de 2019.
// Descripción: Definir la clase ControladorJDBC para gestionar la comunicación básica con JDBC.
//              Leer la documentación técnica doc-técnica.txt para más info.
// Fecha Ver. : Enero de 2025.
// Obs.       : OpenJDK 16, NetBeans IDE 23, OLS r7.9, Windows Server 2016 Standard.
//            : Este módulo no es compatible con Java SDK 8u431.
// Licencia   : GNU GPL ver. 3

/* ControladorJDBC.java
 *
 * Copyright (C) 2025 Eugenio Martínez.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Authors: Eugenio Martínez, https://t.me/octulioBiletan
 */

package posqlinuxlib;

import java.io.IOException;
import java.lang.management.ManagementFactory;
import pConsola.Consola;
import static posqlinuxlib.nombreCtrlJDBC.indefinido;
import static posqlinuxlib.nombreCtrlJDBC.mariadb;
import static posqlinuxlib.nombreCtrlJDBC.microsoft;
import static posqlinuxlib.nombreCtrlJDBC.mysql;
import static posqlinuxlib.nombreCtrlJDBC.oracle;
import static posqlinuxlib.nombreCtrlJDBC.postgresql;
import static posqlinuxlib.nombreCtrlJDBC.sqlite;

/** <b>OSQLinuxLib.jar</b><br>
 * Definición de la clase ControladorJDBC que sirve para registrar el controlador JDBC.
 * @author Octulio Biletán
 */
public class ControladorJDBC
{
    private boolean registrado;		// Control de registro (t/f) del controlador JDBC
    private String sql_ctrl_nombre;	// Nombre del controlador JDBC

    @SuppressWarnings("unused")
    private Class sqlJDBC;		// ID del controlador JDBC registrado

    private Consola consola;		// Para operaciones de E/S estándar

    /**
     * Constructor de la clase ControladorJDBC. Inicializa sus variables internas.<br>
     */
    @SuppressWarnings("unused")
    ControladorJDBC()
    {
        this.registrado = false;
        this.sql_ctrl_nombre = null;
        this.sqlJDBC = null;

        this.consola = new Consola();
    }

    /**
     * Constructor de la clase que registra el controlador de JDBC especificado
     * en 'nm'.<br>
     * Por ejemplo, "org.postgresql.Driver" para PostgreSQL.<br>
     * Otros controladores admitidos:<br>
     * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; * <b>MySQL</b> =
     * "com.mysql.jdbc.Driver".<br>
     * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; * <b>MariaDB</b> =
     * "org.mariadb.jdbc.Driver".<br>
     * @param nm Es el nombre del controlador JDBC admitido para su registro.
     *
     */
    ControladorJDBC(String nm)
    {
        this.consola = new Consola();

        try
        {
            if(nm.equals("indefinido.jdbc.Driver") == true)
            {
                this.sqlJDBC = null;  // controlador indefinido
                this.registrado = false;
            }
            else
            {
                this.sqlJDBC = Class.forName(nm);  // registra el controlador JDBC
                this.registrado = true;
            }

            this.sql_ctrl_nombre = nm;
        }
        catch (ClassNotFoundException ex)
        {
            consola.pantalla().errTexto("<ERROR> " + ex.getMessage());
            consola.pantalla().errTexto("Interfaz inexistente: " + nm);

            this.sql_ctrl_nombre = null;
            this.registrado = false;
        }
    }

    /**
     * Registra el controlador JDBC especificado en 'cj'.<br>
     *
     * @param cj Controlador JDBC que se quiere registrar para su uso.<br>
     * Nombres admitidos son: <i>postgresql</i>, <i>sqlite</i>, <i>mysql</i>, <i>mariadb</i>, <i>oracle</i>, <i>microsoft</i>, <i>indefinido</i>
     * @return Devuelve 'true' si el registro fue exitoso sino 'false'.
     * @since java 16 sdk.
     */
    public boolean jdbcRegistrar(nombreCtrlJDBC cj)
    {
        if (registrado == true)
        {
            return registrado;
        }

        int ndriver = 0;
        String[] ctrl_lista = new NombresCtrlsJDBC().lista;

        switch (cj) {
            case postgresql ->
                ndriver = 0;
            case sqlite ->
                ndriver = 1;
            case mysql ->
                ndriver = 2;
            case mariadb ->
                ndriver = 3;
            case oracle ->
                ndriver = 4;
            case microsoft ->
                ndriver = 5;
            case indefinido ->
                ndriver = 6;
        }

        sql_ctrl_nombre = ctrl_lista[ndriver];

        try
        {
            if(ndriver == 6)    // controlador indefinido
            {
              sqlJDBC = null;
              registrado = false;
            }
            else
            {
              sqlJDBC = Class.forName(sql_ctrl_nombre);  // registra el controlador solicitado
              registrado = true;
            }
        }
        catch (ClassNotFoundException ex)
        {
            consola.pantalla().errTexto("<ERROR> " + ex.getMessage());
            consola.pantalla().errTexto("Interfaz inexistente: " + sql_ctrl_nombre);
            registrado = false;
        }

        return registrado;
    }

    /**
     * Devuelve el nombre del JDBC vigente.
     *
     * @return El nombre completo del controlador JDBC vigente.
     */
    public String jdbcNombre()
    {
        return sql_ctrl_nombre;
    }

    /**
     * Devuelve el estado de registro del controlador.<br>
     * El controlador JDBC debe estar debidamente instalado junto con la
     * aplicación.
     *
     * @return <i>true</i> = está registrado.<br>
     * <i>false</i> = no está registrado.
     */
    public boolean jdbcRegistrado()
    {
        return registrado;
    }

    /**
     * Devuelve el nombre del Sistema Operativo (S.O.) actual.<br>
     * Puede ser <b>linux</b>, <b>windows</b>, etc.
     * @return El nombre del S.O.
     */
    public String SistemaOperativo()
    {
	return (ManagementFactory.getOperatingSystemMXBean().getName()).toLowerCase();
    }

    /**
     * Efectúa un diagnóstico básico sobre el estado de ejecución del servidor
     * SQL.<br>
     * <b>AVISO</b>: Es necesario que se encuentre instalada la aplicación <i>'/usr/bin/nmap'</i>
     * en su sistema Linux/UNIX para efectuar el diagnóstico.<br>
     * En Windows, la aplicación <i>'nmap.exe'</i> debe estar instalada en el directorio
     * "c:\Program Files (x86)\Nmap".<br>
     * @param srv Nombre o IP del servidor SQL local/remoto.
     * @param prt Nº de puerto del servidor SQL a examinar y averiguar su estado operativo.
     * @return El código de salida devuelto por <code>'nmap'</code>.
     * @throws java.io.IOException
     * @throws java.lang.InterruptedException
     */
    public int jdbcDiag(String srv, String prt) throws IOException, InterruptedException
    {
        String nmapAplic;

        if(SistemaOperativo().startsWith("windows") == true)
            nmapAplic = "c:\\Program Files (x86)\\Nmap\\nmap.exe";
        else
            nmapAplic = "/usr/bin/nmap";

        // Por ejemplo: "nmap -p 5432 localhost"
        ProcessBuilder invocar = new ProcessBuilder(nmapAplic, "-p", prt, srv);

        return invocar.inheritIO().start().waitFor();
    }

    /**
     * Efectúa un diagnóstico básico sobre el estado de la/s tarjeta/s de red/es.<br>
     *
     * @return El código de salida devuelto por la aplicación de diagnóstico.<br>
     * Para Linux: <code>'/usr/bin/nmcli'</code>.<br>
     * Para Windows: <code>'c:\Windows\System32\getmac.exe'</code>.<br>
     * Si devuelve -1 es porque no se pudo ejecutar el comando de diagnóstico.
     */
    public int jdbcDiagMedios()
    {
        int estado = -1;
        String nmapAplic;
        ProcessBuilder invocar;

        if(SistemaOperativo().startsWith("windows") == true)
        {
            nmapAplic = "c:\\Windows\\System32\\getmac.exe";
            invocar = new ProcessBuilder(nmapAplic, "-v");
        }
        else
        {
            nmapAplic = "/usr/bin/nmcli";
            invocar = new ProcessBuilder(nmapAplic, "-c", "auto", "d");
        }

        try {
            estado = invocar.inheritIO().start().waitFor();
        } catch (IOException | InterruptedException ex) {
            consola.pantalla().errTexto("·Error: " + ex.getMessage());
            consola.salidaError().println("·Comando: " + invocar.command());
        }

        return estado;
    }
}
