// Proyecto   : OSQLinuxLib
// Paquete    : posqlinuxlib
// Módulo     : package-info.java
// Autor      : Octulio Biletán - Marzo de 2025.
// Descripción: Contiene una breve información descriptiva sobre 'posqlinuxlib'.
//              Leer la documentación técnica doc-técnica.txt para más info.
// Ult. cambio: Julio de 2025.
// Licencia   : GNU GPL ver. 3

/* package-info.java
 *
 * Copyright (C) 2025 Eugenio Martínez.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Authors: Eugenio Martínez, https://t.me/octulioBiletan
 */

/**
 * <pre>Descripción del paquete</pre>
 *  <b>OSQLinuxLib.jar</b><br>
 * <p>Contiene todas las clases necesarias para acceder a un servidor de base de datos SQL.<br>
 * Las operaciones de E/S hacia el servidor SQL se realizan mediante un conector JDBC.<br>
 * Los conectores JDBC admitidos y comprobados hasta ahora son: <code>postgresql y mysql</code>.<br>
 * Los nombres de los conectores JDBC válidos y aceptados son: <i>postgresql</i>, <i>sqlite</i>, <i>mysql</i>, <i>mariadb</i>, <i>oracle</i>, <i>microsoft</i>, <i>indefinido</i>.<br>
 * El nombre 'indefinido' indica que no posee un controlador JDBC asignado. Cuando se utiliza este conector, no efectúa ninguna operación de E/S sobre el servidor SQL.<br>
 * <br>
 * Sugerencia de nombres de conectores para agregar: texto, memoria, paradox, dbase, cobol.<br>
 * El conector 'memoria' se utilizaría para la gestión de la base de datos en la memoria principal.<br>
 * Por ejemplo podría ser útil para "DuckDB".<br>
 * Este paquete, posqlinuxlib, aún se encuentra en fase de desarrollo y prueba (Julio de 2025).<br><br>
 * <u>Developer Manager:</u> Eugenio Martínez.<br>
 * <u>GitHub:</u> https://github.com/torrentelinux/torrentarium/<br>
 * <u>Contacto:</u> https://t.me/octulioBiletan</p>
 */
package posqlinuxlib;
