// Proyecto   : OSQLinuxLib
// Paquete    : posqlinuxlib
// Módulo     : bcBase.java
// Autor      : Octulio Biletán - Marzo de 2025.
// Descripción: Definir la clase bcBase.
//              Esta servirá de base para la clase bcSQL.
//              Leer la documentación técnica doc-técnica.txt para más info.
// Fecha Ver. : Marzo de 2025.
// Obs.       : OpenJDK 16, NetBeans IDE 23, OLS r7.9, Windows Server 2016 Standard.
//            : Este módulo no es compatible con Java SDK 8u431.
// Licencia   : GNU GPL ver. 3

/* bcBase.java
 *
 * Copyright (C) 2025 Eugenio Martínez.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Authors: Eugenio Martínez, https://t.me/octulioBiletan
 */

package posqlinuxlib;

import java.sql.Connection;
import pConsola.Consola;

/** <b>OSQLinuxLib.jar</b><br>
 * Esta servirá de base para la clase bcSQL.
 * @author Octulio Biletán
 */
public class bcBase {
    protected String estadoOperativo;	// Estado operativo de la aplicación, activo/inactivo
    protected String bdd_servidor;	// Nombre del servidor SQL
    protected String bdd_nombre;	// Nombre de la base de datos SQL
    protected String bdd_usuario;	// Nombre de la cuenta del usuario
    protected String bdd_clave;		// Clave de acceso
    protected String bdd_conector;	// Nombre simple del conector JDBC, consultar en NombreCtrlJDBC.java
    protected String bdd_conex;		// Cadena de conexión

    protected String bdd_jdbc_puerto;	    // Puerto por omisión
    protected String bdd_jdbc_url;  	    // URL por omisión
    protected String bdd_jdbc_driver;	    // Controlador por omisión

    protected ControladorJDBC bdd_ctrlJDBC;

    //  Hace referencia a una conexión (sesión) con una base de datos específica.
    //  Las instrucciones SQL se ejecutan y los resultados se devuelven dentro del contexto de una conexión.
    protected Connection bdd_con;

    protected boolean estadoConexion;

    @SuppressWarnings("FieldMayBeFinal")
    protected Consola consola;

    protected String fcredenciales;

    /**
     * Códigos de errores.
     */
    protected enum codigoError {  sin_error,     // sin error
                                errIngreso,      // Falló el ingreso al servidor SQL
                                errArchivo,      // No se encuentra el archivo o no es un archivo regular
                                errInactivo,     // Estado operativo inactivo
                                errCreacion,     // Falló la creación de la base de datos en el servidor SQL
                                errEliminacion,  // Falló la eliminación de la base de datos en el servidor SQL
                                errDesconocido   // Error desconocido, general, no identificable
    }
    protected codigoError codigo_error;	// Ultimo código de error registrado.

    /**
     * Objeto <b>jTabla</b> SQL.<br>
     * Mediante dicho objeto se puede acceder a sus métodos para manipular la tabla y sus datos.<br>
     */
    public jTabla tabla;
}
