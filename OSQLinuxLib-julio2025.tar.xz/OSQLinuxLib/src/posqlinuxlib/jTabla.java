// Proyecto   : OSQLinuxLib
// Paquete    : posqlinuxlib
// Módulo     : jTabla.java
// Autor      : Octulio Biletán - Diciembre de 2024.
// Descripción: Definir la clase jTabla SQL.
//              Leer la documentación técnica doc-técnica.txt para más info.
// Ult. cambio: Marzo de 2025.
// Licencia   : GNU GPL ver. 3

/* jTabla.java
 *
 * Copyright (C) 2025 Eugenio Martínez.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Authors: Eugenio Martínez, https://t.me/octulioBiletan
 */

// __________________________________________________________*

package posqlinuxlib;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import pConsola.Consola;
import pConsola.ConsolaVirtual;

/* Códigos de errores en las diferentes operaciones de E/S sobre la tabla.
   código 0: Sin error.
   código 5: Error en la ejecución del comando SQL sobre la tabla.
*/

/** <b>OSQLinuxLib.jar</b><br>
 * Definición de la clase jTabla SQL.<br>
 * Permite gestionar y realizar operaciones de E/S a la tabla.<br>
 * Las operaciones de E/S permitidas son: crear, agregar, modificar, eliminar y consultar.
 * @see bcSQL
 * @author Octulio Biletán.
 * @since 1.0
 * @version 1.0
 */
public class jTabla
{
    private boolean tb_error;		// Indicador de error detectado true/false
    private int tb_codigo_error;	// Ultimo código de error detectado
    private String tb_nombre;		// Nombre de la tabla vigente
    private Connection tb_con;		// Datos de la conexión vigente a la base de datos

    /**
     * 1º constructor de la clase jTabla SQL.<br>
     * Inicializa los datos internos de esta tabla.
     *
     */
    public jTabla()
    {
        tb_codigo_error = 0;
        tb_error = false;
        tb_con = null;
        tb_nombre = "";
    }

    /**
     * 2º constructor de la clase jTabla SQL.<br>
     * Asocia una sesión abierta/activa al servidor SQL entre la base de datos y esta tabla.
     * @param cnx Conexión/sesión a la base de datos SQL.
     */
    public jTabla(Connection cnx)
    {
        tb_con = cnx;
        tb_codigo_error = 0;
        tb_error = false;
        tb_nombre = "";
    }

    /**
     * Guarda/actualiza en la tabla los datos de la conexión vigente.
     * @param cnx contiene datos de la conexión actual que es de tipo 'Connection'.
     */
    public void guardaSQLCon(Connection cnx)
    {
        tb_con = cnx;
    }

    /**
     * Lee/recupera de la tabla los datos de la conexión vigente.
     * @return Los datos de la conexión vigente.
     */
    public Connection leeSQLCon()
    {
	return tb_con;
    }

    /**
     * Devuelve el nombre de la tabla SQL.
     * @return El nombre de la tabla vigente.
     */
    public String nombre()
    {
        return tb_nombre;
    }

    /**
     * Devuelve true/false si hubo error de E/S en la tabla vigente.
     * @return Si hay error devuelve 'true' sino 'false'.
     */
    public boolean hayError()
    {
        return tb_error;
    }

    /**
     * Devuelve un código de error, 0 o más.<br>
     * No hay error cuando el código es 0.<br>
     * Hay error cuando el código es 1 y en adelante.
     * @return El código de error.
     */
    public int codigoError()
    {
        return tb_codigo_error;
    }

    /**
     * Crea la tabla 'tbnombre' con sus columnas 'tbcols' en la base de datos SQL.<br>
     * Utiliza la sentencia 'create table'.
     *
     * @param tbnombre Nombre de la tabla.
     * @param tbcols Las columnas de la tabla.
     * @return <i>true</i> si todo ha ido bien sino <i>false</i>.
     */
    public boolean crear(String tbnombre, String tbcols)
    {
        boolean status = false;
        Statement st;

        try
        {
            st = tb_con.createStatement();
            st.execute("create table " + tbnombre + "(" + tbcols + ")");

            st.close();
            status = true;
            tb_nombre = tbnombre;
        }
        catch(SQLException ex)
        {
            System.err.println("<Error> " + ex.getMessage());
            System.err.println("Tabla: " + tbnombre);
            System.err.println("Columnas: " + tbcols);
        }

        return status;
    }

    /* FALTA COMPLETAR
    // Elimina la tabla de la base de datos: drop table if exists...
    public boolean eliminarTabla(String tbnombre) { return true; }

    // Modifica/cambia la estructura de la tabla: alter table if exists...
    public boolean modificarTabla(String tbnombre, String tbcols, String tbvals)
    */

    /**
     * Agrega los nuevos datos en la tabla.<br>
     * Utiliza la sentencia 'insert into... values...'.
     * @param tbnombre Nombre de la tabla.
     * @param tbcols Las columnas de la tabla.
     * @param tbvals Los datos de cada columna.
     * @return <i>true</i> si todo ha ido bien sino <i>false</i>.
     */
    public boolean agregar(String tbnombre, String tbcols, String tbvals)
    {
        Statement st;
        boolean status = false;

        try {
            st = tb_con.createStatement();
            st.execute("insert into " + tbnombre + "(" + tbcols + ")" + "values(" + tbvals + ")");

            st.close();
            status = true;
            tb_nombre = tbnombre;
        } catch (SQLException ex) {
            System.err.println("<Error> " + ex.getMessage());
            System.err.println("Tabla: " + tbnombre);
            System.err.println("Columnas: " + tbcols);
            System.err.println("Datos: " + tbvals);
        }

        return status;
    }

    /**
     * Modifica los datos 'tbval' de la columna indicada 'tbcol' correspondiente a la tabla 'tbnombre'.<br>
     * Utiliza la sentencia 'update... set... where...'.
     * @param tbnombre Nombre de la tabla.
     * @param tbcol La columna destino a modificar en la tabla.
     * @param tbval La columna con sus nuevos datos.
     * @return <i>true</i> si todo ha ido bien sino <i>false</i>.
     */
    public boolean modificar(String tbnombre, String tbcol, String tbval)
    {
        boolean status = false;
        int dato = 0;
        String comando;
        Statement st;
        Consola consola = new Consola();

        comando = "update " + tbnombre + " set " + tbval + " where " + tbcol;
        try
        {
            st = tb_con.createStatement();
            dato = st.executeUpdate(comando);
            st.close();

            tb_nombre = tbnombre;

            if(dato < 1)
              consola.salidaStd().println("Advertencia: No se modificó el registro solicitado.");
            else
                status = true;
        }
        catch (SQLException ex)
        {
            consola.salidaError().println("Notifica " + ex.getMessage());
            consola.salidaError().println("Tabla: " + tbnombre);
            consola.salidaError().println("Comando: " + comando);
        }

        return status;
    }

    /**
     * Elimina un registro/fila de la tabla<br>
     * Utiliza la sentencia '<code>delete from...where...</code>'
     * @param tbnombre Nombre de la tabla.
     * @param tbcondicion Condición lógica que se necesita para eliminar el registro/fila de la tabla.
     * @return Mensaje de textos que describe el resultado de eliminar una fila de la tabla.
     */
    public String eliminar(String tbnombre, String tbcondicion)
    {
        int dato;
        String status;
        String cmd;
        Statement sentencia;
        ConsolaVirtual vconsola;

        vconsola = new ConsolaVirtual();
        vconsola.abrir();

        status = "falso";
        cmd = "delete from " + tbnombre + " where " + tbcondicion;

        try
        {
            sentencia = tb_con.createStatement();
            dato = sentencia.executeUpdate(cmd);
            sentencia.close();

            tb_nombre = tbnombre;

            if(dato < 1)
                vconsola.consolaVirtual().println("Advertencia: No se eliminó el registro solicitado.");
            else
            {
                status = "verdadero";
            }
        }
        catch(SQLException ex)
        {
            vconsola.consolaVirtual().println("Notifica " + ex.getMessage());
            vconsola.consolaVirtual().println("Tabla: " + tbnombre);
            vconsola.consolaVirtual().println("Comando: " + cmd);
        }

        vconsola.consolaVirtual().println(status);
        String tmp = vconsola.textoSalida();
        vconsola.cerrar();

        return tmp;
    }

    /**
     * Muestra todo el contenido de una tabla SQL
     * tal como se encuentran almacenados los datos (sin ordenar).<br>
     * @param tbnombre Nombre de la tabla.
     * @return <i>true</i> si todo ha ido bien sino <i>false</i>.
     */
    public boolean mostrarTodo(String tbnombre)
    {
        boolean status = false;
        int ncols;
        Statement st;
        ResultSet rs;
        ResultSetMetaData rsmd;

        try
        {
            st = tb_con.createStatement();
            rs = st.executeQuery("select * from " + tbnombre);

            rsmd = rs.getMetaData();
            ncols = rsmd.getColumnCount();

            while(rs.next())
            {
                for (int i = 1; i <= ncols; i++)
                {
                    System.out.print(rs.getString(i) + " ");
                }

                System.out.println();
            }

            rs.close();
            st.close();

            status = true;
            tb_nombre = tbnombre;
        }
        catch(SQLException ex)
        {
            System.err.println("<Error> " + ex.getMessage());
            System.err.println("Comando SQL: " + ex.toString());
            System.err.println("Tabla: " + tbnombre);
        }

        return status;
    }

    /**
     * Permite ejecutar una sentencia SQL sobre la tabla vigente.<br>
     * En caso de producirse un error de E/S, se puede consultar por el código de
     * error haciendo una llamada al método 'codigoError()'.
     * @param comando Es la sentencia SQL a ejecutar.
     * @return Devuelve como resultado una secuencia de caracteres alfanuméricos,<br>
     * que consiste en una o más líneas de textos a ser analizadas o visualizadas por<br>
     * quién efectuó la llamada a este método.
     */
    public String ejecutarSQL(String comando)
    {
        boolean status;
        int ncols;
        int cuenta;
        String tbnombre;
        Statement sentencia;
        ResultSet rs;
        ResultSetMetaData rsmd;		// FALTA REVISAR
        ConsolaVirtual vconsola;

        tbnombre = tb_nombre;
        tb_error = false;
        tb_codigo_error = 0;

        vconsola = new ConsolaVirtual();
        vconsola.abrir();

	// COMPROBAR CONTENIDO DE 'comando'

        try
        {
            sentencia = tb_con.createStatement();

            status = sentencia.execute(comando);
            if(status == true)
            {
                rs = sentencia.getResultSet();
                rsmd = rs.getMetaData();	// FALTA REVISAR
                ncols = rsmd.getColumnCount();

                while(rs.next())
                {
                    for(int i = 1; i <= ncols; i++)
                    {
                        vconsola.consolaVirtual().print(rs.getString(i) + " ");
                    }

                    vconsola.consolaVirtual().println();
                }

                rs.close();
                sentencia.close();
            }
            else
            {
                cuenta = sentencia.getUpdateCount();
                if(cuenta > 0)
                {
                    tb_error = false;
                    tb_codigo_error = 0;
                }
                else
                {
                    tb_error = true;
                    tb_codigo_error = 5;
                }

                vconsola.consolaVirtual().println(cuenta);
            }
        }
        catch(SQLException ex)
        {
            vconsola.consolaVirtual().println("<Error> " + ex.getMessage());
            vconsola.consolaVirtual().println("Comando SQL: " + comando);
            vconsola.consolaVirtual().println("Tabla: " + tbnombre);

            tb_error = true;
            tb_codigo_error = 5;  // Error en la ejecución del comando SQL sobre la tabla.
        }

        String tmp = vconsola.textoSalida();
        vconsola.cerrar();

        return tmp;
    }
}
