// Proyecto   : OSQLinuxLib
// Paquete    : posqlinuxlib
// Módulo     : nombreCtrlJDBC.java
// Autor      : Octulio Biletán - Diciembre de 2024.
// Descripción: Definir el tipo enum nombreCtrlJDBC.
//              Leer la documentación técnica doc-técnica.txt para más info.
// Ult. cambio: Marzo de 2025.
// Licencia   : GNU GPL ver. 3

/* nombreCtrlJDBC.java
 *
 * Copyright (C) 2025 Eugenio Martínez.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Authors: Eugenio Martínez, https://t.me/octulioBiletan
 */

package posqlinuxlib;

// Pendiente  : Nombres de conectores para agregar: texto, memoria, paradox, dbase, cobol
/** <b>OSQLinuxLib.jar</b><br>
 * Los nombres enumerados de los controladores JDBC válidos y aceptados.<br>
 * Ellos son: <i>postgresql</i>, <i>sqlite</i>, <i>mysql</i>, <i>mariadb</i>, <i>oracle</i>, <i>microsoft</i>, <i>indefinido</i>.<br>
 * El nombre 'indefinido' indica que no posee un controlador JDBC asignado.
 * @author Octulio Biletán
 */
public enum nombreCtrlJDBC
{
    // 0,        1,      2,     3,       4,      5,         6
    postgresql, sqlite, mysql, mariadb, oracle, microsoft, indefinido
}
