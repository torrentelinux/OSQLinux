// Proyecto   : OSQLinuxLib
// Paquete    : posqlinuxlib
// Módulo     : bcSQL.java
// Autor      : Octulio Biletán - Octubre de 2019.
// Descripción: Definir la clase bcSQL y vincularla con JDBC y java.sql
//              Leer la documentación técnica doc-técnica.txt para más info.
// Fecha Ver. : Julio de 2025.
// Obs.       : OpenJDK 16, NetBeans IDE 23, OLS r7.9, Windows Server 2016 Standard.
//            : Este módulo no es compatible con Java SDK 8u431.
// Licencia   : GNU GPL ver. 3

/* bcSQL.java
 *
 * Copyright (C) 2025 Eugenio Martínez.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Authors: Eugenio Martínez, https://t.me/octulioBiletan
 */

package posqlinuxlib;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.*;
import java.util.Properties;
import java.util.logging.*;
import pConsola.*;
import static posqlinuxlib.nombreCtrlJDBC.indefinido;
import static posqlinuxlib.nombreCtrlJDBC.mariadb;
import static posqlinuxlib.nombreCtrlJDBC.microsoft;
import static posqlinuxlib.nombreCtrlJDBC.mysql;
import static posqlinuxlib.nombreCtrlJDBC.oracle;
import static posqlinuxlib.nombreCtrlJDBC.postgresql;
import static posqlinuxlib.nombreCtrlJDBC.sqlite;

// __________________________________________________________*
/** <b>OSQLinuxLib.jar</b><br>
 * Definición de la clase {@code bcSQL}.<br>
 * {@summary <b>Resumen</b>}<br>
 * <blockquote>Permite establecer la conexión a un servidor de base de datos SQL para operar con
 * él.<br>La conexión se lleva a cabo mediante un controlador JDBC.<br>
 * Se pueden realizar las siguientes operaciones con la base de datos: abrir,
 * cerrar, crear, borrar y modificar.<br></blockquote>
 * Tutorial básico sobre cómo acceder a una base de datos a través de
 * la interfaz JDBC, <a
 * href="https://docs.oracle.com/javase/tutorial/jdbc/basics/index.html"
 * target="_blank">clic aquí</a> para acceder.<br>
 *
 * @see jTabla
 * @see java.sql.DriverManager
 * @see java.sql.Connection
 * @see java.sql
 * @author Octulio Biletán.
 * @since 1.0
 * @version 1.0
*/
public class bcSQL extends bcBase
{
    /**
     * Constructor de la clase bcSQL. Inicializa la mencionada clase.
     */
    public bcSQL()
    {

        NombresCtrlsJDBC ctrls;
        ctrls = new NombresCtrlsJDBC();
        consola = new Consola();
        fcredenciales = "credenciales.properties";

        estadoOperativo = null;
        bdd_servidor = null;
        bdd_nombre = null;
        bdd_usuario = null;
        bdd_clave = null;
	bdd_conector = nombreCtrlJDBC.indefinido.name();
        bdd_conex = null;

        // Valores por omisión: indefinido
        bdd_jdbc_driver = ctrls.isqlControlador();
        bdd_jdbc_url = ctrls.isqlURL();
        bdd_jdbc_puerto = ctrls.isqlPuerto();

        bdd_con = null;
        bdd_ctrlJDBC = null;
        tabla = null;
        estadoConexion = false;
        codigo_error = codigoError.sin_error;
    }

    /**
     * Devuelve el número de versión de la biblioteca de clases {@code OSQLinuxLib}.
     * @return El nro. de versión de la mencionada clase.
     */
    public String version_bcSQL()
    {
        return "1.7.2025";
    }

    /**
     * Devuelve el nombre de la serie correspondiente a la edición OSQLinuxLib.
     * @return El nombre de la serie.
     */
    public String serie_bcSQL()
    {
        return "SQLinux";
    }

    /**
     * Devuelve una breve descripción explicativa acerca de la biblioteca de clases {@code bcSQL}.
     * @return La descripción de la mencionada clase.
     */
    public String descripcion_bcSQL()
    {
        return "Biblioteca de clases para la conexión y comunicación con servidor SQL mediante la interfaz JDBC.";
    }

    /**
     * Devuelve el nombre de la biblioteca de clases {@code bcSQL}.
     * @return El nombre de la mencionada clase.
     */
    public String nombre_bcSQL()
    {
        return getClass().getSimpleName();
    }

    /**
     * Devuelve la condición operativa de la aplicación.<br>
     *
     * @return "activo" o "inactivo"
     */
    public String condicionOperativa()
    {
	return estadoOperativo;
    }

    /**
     * Devuelve el nombre de la base de datos SQL en uso.<br>
     *
     * @return El nombre de la base de datos vigente.
     */
    @SuppressWarnings("unused")
    public String nombre()
    {
        return bdd_nombre;
    }

    /**
     * Devuelve el nombre del servidor de la base de datos SQL.<br>
     *
     * @return El nombre del servidor vigente.
     */
    @SuppressWarnings("unused")
    public String obtenerNombreServidor()
    {
        return bdd_servidor;
    }

    /**
     * Devuelve el último código de error registrado.<br>
     * Ocacionado por una operación de E/S al servidor SQL o por otros motivos externos al mencionado servidor.<br>
     * Códigos válidos:
     *		0 (sin error),
     *		1 (Falló el ingreso al servidor SQL),
     *		2 (No se encuentra el archivo o no es un archivo regular),
     *		3 (Estado operativo inactivo),
     *		4 (Falló la creación de la base de datos en el servidor SQL),
     *		5 (Falló la eliminación de la base de datos en el servidor SQL).
     * @return El código de error, es de tipo 'int'.
     */
    public int ultimoError()
    {
        return codigo_error.ordinal();
    }

    /**
     * Devuelve el nombre completo del fichero de texto que contiene las credenciales de acceso al servidor SQL.<br>
     * Importante: para más info. sobre el mencionado fichero, leer en doc/doc-técnica.txt.
     * @return El nombre del fichero de las credenciales.
     */
    public String nombreFicCredenciales()
    {
        return fcredenciales;
    }

    /**
     * Devuelve el nombre del controlador JDBC vigente.
     * @return El nombre del controlador JDBC, tipo enum nombreCtrlJDBC.
     */
    public nombreCtrlJDBC nombreConector()
    {
        return nombreCtrlJDBC.valueOf(bdd_conector);
    }

    /**
     * Registra el controlador JDBC para las operaciones de E/S y así acceder al servidor SQL.
     * @param cj Nombre del controlador JDBC admitido.
     * @return <i>true</i> si todo ha ido bien sino <i>false</i>.
     * @since java 16 sdk.
     */
    public boolean registrar(nombreCtrlJDBC cj)
    {
	    int ndriver = 0;
	    boolean estado;
	    NombresCtrlsJDBC ctrls;

        ctrls = new NombresCtrlsJDBC();
        estadoConexion = false;

        bdd_con = null;
        codigo_error = codigoError.sin_error;

        switch (cj) {
            case postgresql -> {
                ndriver = 0;
                bdd_jdbc_driver = ctrls.psqlControlador();
                bdd_jdbc_url = ctrls.psqlURL();
                bdd_jdbc_puerto = ctrls.psqlPuerto();
            }

            case sqlite -> {
                ndriver = 1;
                bdd_jdbc_driver = ctrls.ssqlControlador();
                bdd_jdbc_url = ctrls.ssqlURL();
                bdd_jdbc_puerto = ctrls.ssqlPuerto();
            }

            case mysql -> {
                ndriver = 2;
                bdd_jdbc_driver = ctrls.msqlControlador();
                bdd_jdbc_url = ctrls.msqlURL();
                bdd_jdbc_puerto = ctrls.msqlPuerto();
            }

            case mariadb -> {
                ndriver = 3;
                bdd_jdbc_driver = ctrls.masqlControlador();
                bdd_jdbc_url = ctrls.masqlURL();
                bdd_jdbc_puerto = ctrls.masqlPuerto();
            }

            case oracle -> {
                ndriver = 4;
                bdd_jdbc_driver = ctrls.osqlControlador();
                bdd_jdbc_url = ctrls.osqlURL();
                bdd_jdbc_puerto = ctrls.osqlPuerto();
            }

            case microsoft -> {
                ndriver = 5;
                bdd_jdbc_driver =  ctrls.mssqlControlador();
                bdd_jdbc_url = ctrls.mssqlURL();
                bdd_jdbc_puerto = ctrls.mssqlPuerto();
            }

            case indefinido -> ndriver = 6;
        }

        bdd_conex = bdd_jdbc_url;

        // Registra el controlador JDBC según lo especificado en 'cj'
        bdd_ctrlJDBC = new ControladorJDBC(ctrls.lista[ndriver]);

        estado = bdd_ctrlJDBC.jdbcRegistrado();

        tabla = new jTabla(bdd_con);
        return estado;
    }

    /**
     * Crea la base de datos en el servidor SQL.
     * @param bdnombre Nombre de la base de datos.
     * @return <i>true</i> si todo ha ido bien sino <i>false</i>.
     */
    public boolean crear(String bdnombre)
    {
        boolean estado = false;
        String bdd_nueva = bdnombre;
        Statement st;

        if(estadoOperativo.equals("inactivo"))
        {
          codigo_error = codigoError.errInactivo;  // estado operativo inactivo
          return estado;
        }

        if(bdnombre.isBlank() == true || bdnombre.isEmpty() == true)
        {
            return estado;  // dato 'bdnombre' es incorrecto
        }

        codigo_error = codigoError.sin_error;

        try
        {
            st = bdd_con.createStatement();
            st.execute("create database " + bdd_nueva);

            ResultSet salida;
            salida = st.getResultSet();
            if(salida != null)
            {
                consola.pantalla().errTexto(salida.getWarnings().getMessage() );
                estado = false;
            }
            else
                estado = true;

            st.close();
        }
        catch (SQLException ex)
        {
            consola.pantalla().errTexto("<Error> " + ex.getMessage());
            codigo_error = codigoError.errCreacion;
        }

        return estado;
    }

    /**
     * Borra la base de datos del servidor SQL.
     * @param bdnombre Nombre de la base de datos.
     * @return <i>true</i> si todo ha ido bien sino <i>false</i>.
     */
    public boolean borrar(String bdnombre)
    {
        boolean estado = false;
        Statement st;

        if(estadoOperativo.equals("inactivo"))
        {
          codigo_error = codigoError.errInactivo;  // estado operativo inactivo
          return estado;
        }

        if(bdnombre.isBlank() == true || bdnombre.isEmpty() == true)
        {
            return estado;  // dato 'bdnombre' es incorrecto
        }

        codigo_error = codigoError.sin_error;

        try
        {
            st = bdd_con.createStatement();
            st.execute("drop database if exists " + bdnombre);

            ResultSet salida;
            salida = st.getResultSet();
            if(salida != null)
            {
                consola.pantalla().errTexto(salida.getWarnings().getMessage() );
                estado = false;
            }
            else
                estado = true;

            st.close();
        }
        catch (SQLException ex)
        {
            consola.pantalla().errTexto("<Error> " + ex.getMessage());
            consola.pantalla().errTexto("Argumento: " + bdnombre);

            codigo_error = codigoError.errEliminacion;
            estado = false;
        }

        return estado;
    }

    /**
     * Abre la base de datos 'bdnombre' que se encuentra almacenada en el servidor SQL.<br>
     *
     * @param bdnombre Nombre de la base de datos.
     * @return true = Si fue exitosa la apertura de la base de datos.<br>
     * false = Si falló la apertura de la base de datos.<br>
     */
    public boolean abrir(String bdnombre)
    {
        boolean estado;
        Console consolaSistema;
        PrintStream salidaError = consola.salidaError();

        if(estadoOperativo.equals("inactivo"))
        {
          codigo_error = codigoError.sin_error;  // estado operativo inactivo
          return false;
        }

        try
        {
            if (bdd_con.isClosed() == false)
            {
                cerrar();
            }

            //bdd_servidor = "localhost";
            bdd_nombre = bdnombre;

            // Compone la 'cadena de conexión'
            bdd_conex = bdd_jdbc_url + bdd_servidor + ":" + bdd_jdbc_puerto + "/" + bdd_nombre;

            // Si bdd_usuario no contiene datos, se ingresarán sus datos
            // de manera manual a través del teclado.
            if (bdd_usuario.isEmpty())
            {
                consolaSistema = System.console();
                if (consola != null)
                {
                    consola.salidaStd().print("Nombre de la cuenta: ");
                    bdd_usuario = consolaSistema.readLine();

                    consola.salidaStd().print("Contraseña: ");
                    char[] lee_clave = consolaSistema.readPassword();
                    bdd_clave = String.valueOf(lee_clave);
                }
            }

            try
            {
                bdd_con = DriverManager.getConnection(bdd_conex, bdd_usuario, bdd_clave);
                // PONER >> Si mysql entonces 'use bdd_nombre' <<

                tabla.guardaSQLCon(bdd_con);

                estadoConexion = true;
                estado = true;
            }
            catch (SQLException ex)
            {
                salidaError.println("Código Error: " + ex.getErrorCode());
                salidaError.println("Mensaje: " + ex.getMessage());

                estadoConexion = false;
                estado = false;
            }
        }
        catch (SQLException ex)
        {
            Logger.getLogger(bcSQL.class.getName()).log(Level.SEVERE, null, ex);
            estado = false;
        }

        return estado;
    }

    /**
     * Cierra la conexión a la base de datos que se encuentra en el servidor SQL.<br>
     * @return <i>true</i> si todo ha ido bien sino <i>false</i>.
     */
    public boolean cerrar()
    {
        boolean status = false;

        if(estadoOperativo.equals("inactivo"))
        {
          codigo_error = codigoError.errInactivo;  // estado operativo inactivo
          return false;
        }

        try {
            if (bdd_con.getAutoCommit() == false) {
                bdd_con.commit();
            }

            bdd_con.close();

            estadoConexion = false;
            status = true;
        } catch (SQLException ex) {
            Logger.getLogger(bcSQL.class.getName()).log(Level.SEVERE, null, ex);
        }

        return status;
    }

    /**
     * Modifica los atributos de la base de datos vigente.<br>
     * Utiliza la sentencia <code>'alter database...'</code> para efectuar los cambios.<br>
     * <b>Ejemplo: </b><code>bdd.modificar("agenda", "with connection limit -1");</code>
     * @param bdnombre Nombre de la base de datos a modificar.
     * @param params Los parámetros que acompañan al nombre de la base de datos.
     * @return <i>true</i> si todo ha ido bien sino <i>false</i>.
     */
    public boolean modificar(String bdnombre, String params)
    {
        boolean status = false;
        String comando;
        Statement sentencia;

        if(estadoOperativo.equals("inactivo"))
        {
          codigo_error = codigoError.errInactivo;  // estado operativo inactivo
          return false;
        }

        comando = "alter database " + bdnombre + " " + params;

        try {
            sentencia = bdd_con.createStatement();
            sentencia.execute(comando);

            sentencia.close();
            status = true;
        } catch (SQLException ex) {
            consola.pantalla().errTexto("<Error> " + ex.getMessage());
            consola.pantalla().errTexto("Comando: " + comando);
        }

        return status;
    }

    /**
     * Solicita al usuario que ingrese los siguientes datos
     * por teclado: nombre de servidor local/remoto SQL, nombre de la base de datos,<br>
     * cuenta de usuario y contraseña.<br>
     * En caso de error de conexión devuelve 'false' y en caso de éxito devuelve
     * 'true'.
     *
     * @return true = Los datos solicitados fueron ingresados correctamente.<br>
     * false = Error en la entrada de los datos solicitados.
     * @throws IOException Excepción de E/S.
     * @throws InterruptedException Excepción por interrupción.
     */
    public boolean solicitar_ingreso() throws IOException, InterruptedException {
        boolean status = false;
        Console consolaSistema;
        PrintStream salidaError = consola.salidaError();

        if (bdd_conex == null) {
            salidaError.println("ERROR: Debe registrar primero el controlador JDBC para iniciar sesión.");
            return status;
        }

        consolaSistema = System.console();
        if(consola != null) {
            System.out.print("Nombre del servidor: ");
            bdd_servidor = consolaSistema.readLine();

            System.out.print("Nombre de la base de datos: ");
            bdd_nombre = consolaSistema.readLine();

            System.out.print("Nombre de la cuenta: ");
            bdd_usuario = consolaSistema.readLine();

            System.out.print("Contraseña: ");
            char[] lee_clave = consolaSistema.readPassword();
            bdd_clave = String.valueOf(lee_clave);

            // Compone la 'cadena de conexión'
            bdd_conex = bdd_conex + bdd_servidor + ":" + bdd_jdbc_puerto + "/" + bdd_nombre;

            try {
                bdd_con = DriverManager.getConnection(bdd_conex, bdd_usuario, bdd_clave);
                bdd_con.setAutoCommit(true);

                tabla.guardaSQLCon(bdd_con);

                estadoConexion = true;
                status = true;
                estadoOperativo = "activo";
            } catch (SQLException ex) {
                salidaError.println("--------------");
                salidaError.println("Código Error: " + ex.getErrorCode());
                salidaError.println("Estado SQL: " + ex.getSQLState());
                salidaError.println("Mensaje: " + ex.getMessage());
                salidaError.println("Error: Revise los argumentos empleados en la conexión.");

                salidaError.println("Conexión: " + bdd_conex);
                salidaError.println("Usuario/clave: " + bdd_usuario + "/" + bdd_clave);
                salidaError.println();

                salidaError.println("Sugerencia: Revise el archivo de configuración de PostgreSQL: pg_hba.conf");
                salidaError.println("JDBC vigente: " + bdd_ctrlJDBC.jdbcNombre());

                salidaError.printf("Diagnóstico: %d\n", bdd_ctrlJDBC.jdbcDiag(bdd_servidor, bdd_jdbc_puerto));
                salidaError.println("Diagnóstico: " + bdd_ctrlJDBC.SistemaOperativo());
                salidaError.println("--------------");

                estadoConexion = false;
                estadoOperativo = "inactivo";
            }
        }
        else
        {
            salidaError.println("Error al abrir la consola.");
        }

        return status;
    }

    /**
     * Solicita el ingreso al servidor SQL.<br>Lee los datos del usuario desde el fichero 'fcred'.
     * Dicho fichero debe tener la extensión '.properties' a continuación de su nombre, por ejemplo "datos.properties".<br>
     * El mismo puede estar ubicado en cualquier directorio del sistema de archivos (local/remoto).<br>
     * Entonces: estado = solicitar_ingreso("datos");
     * @param fcred Nombre del fichero de credenciales que tiene los datos de la cuenta del usuario (no poner la extensión).
     * @return <i>true</i> si la conexión fue exitosa sino <i>false</i>.
     * @throws IOException Excepción de E/S.
     * @throws InterruptedException Excepción por interrupción.
     */
    public boolean solicitar_ingreso(String fcred) throws IOException, InterruptedException
    {
        boolean status = false;
	boolean siga = false;
        PrintStream salidaError = consola.salidaError();

        if(bdd_conex == null)
	{
            // Es necesario registrar el driver JDBC
	    siga = true;
        }

        if(!fcred.contains(".properties".toLowerCase()))
        {
            // Se agrega la extensión válida al final del nombre del fichero.
            fcred = fcred + ".properties";
        }

        if(existeFichero(fcred))
        {
            estadoOperativo = estadoCredenciales(fcred);

            bdd_servidor = servidorCredenciales(fcred);
            bdd_nombre = bddCredenciales(fcred);

            bdd_usuario = cuentaCredenciales(fcred);
            bdd_clave = claveCredenciales(fcred);

	    if(siga)  // ¿ realmente registro driver JDBC ?
	    {
		// Lee de credenciales el campo conector
		bdd_conector = conectorCredenciales(fcred).name();
                boolean resultado;

                // Paso 1º: registrar el controlador JDBC que se quiere utilizar para iniciar
                // las operaciones de E/S en el servidor SQL.
                nombreCtrlJDBC nc_jdbc = nombreCtrlJDBC.valueOf(bdd_conector);

                resultado = registrar(nc_jdbc);
                if(resultado == false)
                {
                    consola.pantalla().errTexto("<AVISO> El controlador JDBC " + nc_jdbc.toString() + " no se encuentra debidamente registrado.");
                }
	    }
        }
        else
        {
          return false;  // no existe el fichero 'fcred'
        }

        fcredenciales = fcred;

        // Compone la 'cadena de conexión'
        bdd_conex = bdd_conex + bdd_servidor + ":" + bdd_jdbc_puerto + "/" + bdd_nombre;

        try
	{
            bdd_con = DriverManager.getConnection(bdd_conex, bdd_usuario, bdd_clave);
            bdd_con.setAutoCommit(true);

            tabla.guardaSQLCon(bdd_con);

            estadoConexion = true;
            status = true;
        }
	catch(SQLException ex)
	{
            salidaError.println("--------------");
            salidaError.println("Código Error: " + ex.getErrorCode());
            salidaError.println("Estado SQL: " + ex.getSQLState());
            salidaError.println("Mensaje: " + ex.getMessage());
            salidaError.println("Error: Revise los argumentos empleados en la conexión.");

            salidaError.println("Conexión: " + bdd_conex);
            salidaError.println("Usuario/clave: " + bdd_usuario + "/" + bdd_clave);
            salidaError.println();

            salidaError.println("Sugerencia: Revise el archivo de configuración del servidor SQL.");
            salidaError.println("JDBC vigente: " + bdd_ctrlJDBC.jdbcNombre());

            salidaError.println("Diag. sobre puerto:");
            bdd_ctrlJDBC.jdbcDiag(bdd_servidor, bdd_jdbc_puerto);

            salidaError.println("Diag. sobre los medios de conexión:");
            bdd_ctrlJDBC.jdbcDiagMedios();

            salidaError.println("Diag.: " + bdd_ctrlJDBC.SistemaOperativo());
            salidaError.println("Diag.: " + nombreFicCredenciales());
            salidaError.println("--------------");

            estadoConexion = false;
            codigo_error = codigoError.errIngreso;  // Falló el ingreso al servidor SQL
        }

        return status;
    }

    // lee la condición del estado operativo de la aplicación
    private String estadoCredenciales(String fcred) {
        String campo_estado = "";
        Properties propiedades = new Properties();

        try {
            propiedades.load(new FileInputStream(fcred));

            for (String campo : propiedades.stringPropertyNames()) {
                String valor = propiedades.getProperty(campo);

                if (campo.equalsIgnoreCase("estado") == true) {
                    campo_estado = valor;
                    break;
                }
            }
        } catch (IOException error) {
              consola.pantalla().errTexto("Error: " + error.getMessage());
        }

        return campo_estado;
    }

    // nombre del servidor de base de datos
    private String servidorCredenciales(String fcred) {
        String nombre_servidor = "";
        Properties propiedades = new Properties();

        try {
            propiedades.load(new FileInputStream(fcred));

            for (String campo : propiedades.stringPropertyNames()) {
                String valor = propiedades.getProperty(campo);

                if (campo.equalsIgnoreCase("servidor") == true) {
                    nombre_servidor = valor;
                    break;
                }
            }
        } catch (IOException error) {
              consola.pantalla().errTexto("Error: " + error.getMessage());
        }

        return nombre_servidor;
    }

    // nombre de la base de datos
    private String bddCredenciales(String fcred) {
        String nombre_bdd = "";
        Properties propiedades = new Properties();

        try {
            propiedades.load(new FileInputStream(fcred));

            for (String campo : propiedades.stringPropertyNames()) {
                String valor = propiedades.getProperty(campo);

                if (campo.equalsIgnoreCase("bdnombre") == true) {
                    nombre_bdd = valor;
                    break;
                }
            }
        } catch (IOException error) {
            consola.pantalla().errTexto("Error: " + error.getMessage());
        }

        return nombre_bdd;
    }

    // nombre de la cuenta del usuario
    private String cuentaCredenciales(String fcred) {
        String nombre_cuenta = "";
        Properties propiedades = new Properties();

        try {
            propiedades.load(new FileInputStream(fcred));

            for (String campo : propiedades.stringPropertyNames()) {
                String valor = propiedades.getProperty(campo);

                if (campo.equalsIgnoreCase("cuenta") == true) {
                    nombre_cuenta = valor;
                    break;
                }
            }
        } catch (IOException error) {
            consola.pantalla().errTexto("Error: " + error.getMessage());
        }

        return nombre_cuenta;
    }

    // clave de acceso de la cuenta del usuario
    private String claveCredenciales(String fcred)
    {
        String clave = "";
        Properties propiedades = new Properties();

        try {
            propiedades.load(new FileInputStream(fcred));

            for (String campo : propiedades.stringPropertyNames()) {
                String valor = propiedades.getProperty(campo);

                if (campo.equalsIgnoreCase("clave") == true) {
                    clave = valor;
                    break;
                }
            }
        } catch (IOException error) {
            consola.pantalla().errTexto("Error: " + error.getMessage());
        }

        return clave;
    }

    // Lee desde 'fcred' el conector JDBC a emplear por la aplicación
    private nombreCtrlJDBC conectorCredenciales(String fcred)
    {
        String conector = "";
        nombreCtrlJDBC resultado;
        Properties propiedades = new Properties();

        try
        {
            propiedades.load(new FileInputStream(fcred));

            for (String campo : propiedades.stringPropertyNames())
            {
                String valor = propiedades.getProperty(campo);

                if (campo.equalsIgnoreCase("conector") == true)
                {
                    conector = valor;
                    break;
                }
            }

            resultado = nombreCtrlJDBC.valueOf(conector);
        }
        catch (IOException error)
        {
            consola.pantalla().errTexto("Error: " + error.getMessage());
            consola.salidaError().println("Conector leído: [" + conector + "]");

            resultado = nombreCtrlJDBC.indefinido;
        }

        return resultado;
    }

    /**
     * Devuelve info. sobre la versión del servidor de base de datos SQL.<br>
     *
     * @return La versión del servidor SQL vigente.
     */
    public String version()
    {
        String resultado = "";
        Statement st;
        ResultSet rs;

        if(estadoOperativo.equals("inactivo"))
        {
          codigo_error = codigoError.errInactivo;  // estado operativo inactivo
          return resultado;
        }

        try {
            st = bdd_con.createStatement();
            rs = st.executeQuery("select version()");

            while (rs.next()) {
                resultado += rs.getString(1) + " ";
            }

            rs.close();
            st.close();
        } catch (SQLException | NullPointerException ex) {
            consola.pantalla().errTexto("Error: [version()]" + ex.getMessage());
        }

        return resultado;
    }

    /**
     * Devuelve info. sobre la versión del S.O.<br>
     *
     * @return La versión del S.O. vigente.
     */
    public String versionSO() {
        String texto = System.getProperty("os.name") + "/" + System.getProperty("os.arch");
        StringWriter linea = new StringWriter();

        linea.append(texto);
        return linea.toString();
    }

    /**
     * Devuelve info. sobre el nombre del producto del S.O. detectado.<br>
     *
     * @return El nombre completo del S.O. detectado.
     */
    public String productoSO() {
        boolean bandera = false;
        String texto = "desconocido";
        String fnombre = "/etc/system-release";  // La 1ra. opción
        BufferedReader fichero;

        if (versionSO().toLowerCase().startsWith("linux")) {
            try {
                File etc_release = new File(fnombre);
                if (etc_release.isFile() == false) {
                    fnombre = "/etc/os-release";  // como 2da. opción
                    bandera = true;
                }

                fichero = new BufferedReader(new FileReader(fnombre));

                texto = fichero.readLine();  // lee la 1ra. línea del archivo
                if (bandera == true) {
                    texto = texto.substring(texto.indexOf("=") + 1).replace('"', ' ').trim();
                }

                fichero.close();
            } catch (FileNotFoundException ex) {
                consola.pantalla().errTexto("No se encuentra el archivo " + fnombre);
                consola.pantalla().errTexto(ex.getMessage());
            } catch (IOException ex) {
                consola.pantalla().errTexto("Error de lectura en el archivo " + fnombre);
                consola.pantalla().errTexto(ex.getMessage());
            }
        }
        else
            texto = versionSO();

        return texto;
    }

    /**
     *
     * @return
     */
    public String listarBD() {
        int ncols;
        String pg_bases = "pg_database";  // Cambiar esto
        String resultado = "";
        Statement st;
        ResultSet rs;
        ResultSetMetaData rsmd;

        if(estadoOperativo.equals("inactivo"))
        {
          codigo_error = codigoError.errInactivo;  // estado operativo inactivo
          return resultado;
        }

        try {
            st = bdd_con.createStatement();
            rs = st.executeQuery("select oid,datname from " + pg_bases + " order by datname");

            rsmd = rs.getMetaData();
            ncols = rsmd.getColumnCount();

            // Obtiene los nombres de las columnas
            for (int n = 1; n <= ncols; n++) {
                resultado = resultado.concat("  " + rsmd.getColumnName(n) + " ");
            }

            resultado = resultado.concat("\n");

            // Obtiene los datos de cada columna
            while (rs.next()) {
                for (int i = 1; i <= ncols; i++) {
                    resultado = resultado.concat(rs.getString(i) + "\t");
                }

                resultado = resultado.concat("\n");
            }

            rs.close();
            st.close();
        } catch (SQLException ex) {
            consola.pantalla().errTexto("<Error> " + ex.getMessage());
            consola.pantalla().errTexto("Comando SQL: " + ex.toString());
            consola.pantalla().errTexto("Tabla: " + pg_bases);
        }

        return resultado;
    }

    /**
     * Permite cambiar la contraseña de la cuenta del usuario 'usr'.<br>
     * Se permite en 'clv' una clave vacía.<br><br>
     * <b>Uso:</b>
     * <code>boolean estado = cambiarClave("nombre_cuenta_usuario", "nueva_contraseña_usuario");</code><br>
     *
     * @param usr Usuario.
     * @param clv Contraseña.
     * @return Devuelve <i>true</i> si todo ha salido bien sino <i>false</i>.
     */
    public boolean cambiarClave(String usr, String clv)
    {
        boolean estado;
        String comando;

        if(estadoOperativo.equals("inactivo"))
        {
          codigo_error = codigoError.errInactivo;  // estado operativo inactivo
          return false;
        }

        if (usr.isBlank() == true) {
            return false;  // dato 'usr' es incorrecto
        }

        comando = "alter user ";
        comando = comando.concat(usr);
        comando = comando.concat(" with password '");
        comando = comando.concat(clv);
        comando = comando.concat("'");

        try {
            Connection ois = obtenerInfoSesion();
            Statement cs = ois.createStatement();

            cs.execute(comando);
            estado = true;
        } catch (SQLException ex) {
            consola.pantalla().errTexto("<Error> " + ex.getMessage());
            consola.pantalla().errTexto("Comando SQL: " + comando);
            consola.pantalla().errTexto("Usuario: " + usr);

            estado = false;
        }

        return estado;
    }

    /**
     * Efectúa una consulta, en el servidor SQL, si la cuenta del usuario <i>'cta'</i> existe o no.<br>
     * El parámetro <i>'cta'</i> no debe contener espacios en blanco ni estar vacía.<br>
     * @param cta Nombre de la cuenta a consultar.
     * @return Devuelve <i>true</i> si la mencionada cuenta existe sino <i>false</i>.
     */
    @SuppressWarnings("UnusedAssignment")
    public boolean existeCuenta(String cta)
    {
        boolean estado = false;
        int dato;
        String comando;
        ResultSet rs;

        if(estadoOperativo.equals("inactivo"))
        {
          codigo_error = codigoError.errInactivo;  // estado operativo inactivo
          return estado;
        }

        if (cta.isBlank() == true || cta.isEmpty() == true)
        {
            return estado;  // dato 'cta' es incorrecto
        }

        dato = 0;
        comando = "select 1 from pg_roles where rolname='" + cta + "'";

        try
        {
            Connection ois = obtenerInfoSesion();
            Statement cs = ois.createStatement();

            rs = cs.executeQuery(comando);
            if(rs.next())
            {
                dato = rs.getInt(1);
                estado = dato == 1;  // La cuenta del usuario sí existe si dato = 1
            }
            else
                estado = false;  // La cuenta del usuario no existe
        }
        catch (SQLException ex)
        {
            consola.pantalla().errTexto("<Error> " + ex.getMessage());
            consola.pantalla().errTexto("Comando SQL: " + comando);
            consola.pantalla().errTexto("Usuario: " + cta);

            estado = false;
        }

        return estado;
    }

    /**
     * Crea una nueva cuenta de usuario en el servidor SQL.
     * @param cta Nombre de la cuenta a crear. No se admiten espacios en blanco ni nulas.
     * @return Devuelve <i>true</i> si la mencionada cuenta se creó satisfactoriamente sino <i>false</i>.
     */
    public boolean crearCuenta(String cta)
    {
        boolean estado = false;
        int cuenta;
        String comando;
        String resultado;

        if(estadoOperativo.equals("inactivo"))
        {
          codigo_error = codigoError.errInactivo;  // estado operativo inactivo
          return estado;
        }

        if (cta.isBlank() == true || cta.isEmpty() == true)
        {
            return estado;  // dato 'cta' es incorrecto
        }

        comando = "create role " + cta + " with login";
        cuenta = 0;

        try {
            Connection ois = obtenerInfoSesion();
            Statement cs = ois.createStatement();

            resultado = "";
            estado = cs.execute(comando);
            if(estado == true)
            {
              ResultSet salida = cs.getResultSet();

              salida.next();
              resultado = salida.getString(1);
            }
            else
              cuenta = cs.getUpdateCount();

            if(resultado.isEmpty())
                estado = true;

            if(cuenta < 1)
            {
                estado = true;
            }
        }
        catch (SQLException ex)
        {
            consola.pantalla().errTexto("<Error> " + ex.getMessage());
            consola.pantalla().errTexto("Comando SQL: " + comando);
            consola.pantalla().errTexto("Usuario: " + cta);

            estado = false;
        }

        return estado;
    }

    /**
     * Devuelve la lista de usuarios registrados en el servidor SQL.
     * @return Devuelve tipo 'String'.
     */
    public String usuarios()
    {
        int ncols;
        String pg_usuarios = "pg_user";  // Cambiar: dominio de postgresql
        String resultado = "";
        Statement st;
        ResultSet rs;
        ResultSetMetaData rsmd;

        if(estadoOperativo.equals("inactivo"))
        {
          codigo_error = codigoError.errInactivo;  // estado operativo inactivo
          return resultado;
        }

        try
        {
            st = bdd_con.createStatement();
            rs = st.executeQuery("select * from " + pg_usuarios);

            rsmd = rs.getMetaData();
            ncols = rsmd.getColumnCount();

            // Obtiene los nombres de las columnas
            for(int n = 1; n <= ncols; n++)
            {
                resultado = resultado.concat(rsmd.getColumnName(n) + " \t");
            }

            resultado = resultado.concat("\n");

            // Obtiene los datos de cada columna
            while(rs.next())
            {
                for(int i = 1; i <= ncols; i++)
                {
                    resultado = resultado.concat(rs.getString(i) + " \t    ");
                }

                resultado = resultado.concat("\n");
            }

            rs.close();
            st.close();
        }
        catch(SQLException | NullPointerException ex)
        {
            consola.pantalla().errTexto("<Error> " + ex.getMessage());
            consola.pantalla().errTexto("Comando SQL: " + ex.toString());
            consola.pantalla().errTexto("Tabla: " + pg_usuarios);
        }

        return resultado;
    }

    /**
     *
     * @return
     * @throws SQLException
     */
    public String controladorInfo() throws SQLException
    {
        String salida;

        if(estadoConexion)
        {

            DatabaseMetaData metaData = bdd_con.getMetaData();

            String databaseProductName = metaData.getDatabaseProductName();
            String databaseProductVersion = metaData.getDatabaseProductVersion();
            String driverName = metaData.getDriverName();
            String driverVersion = metaData.getDriverVersion();

            salida = String.format("Nombre del producto de la base de datos: %s\n"
                    + "Versión del producto de la base de datos: %s\n"
                    + "Nombre del controlador: %s\n"
                    + "Versión del controlador: %s",
                    databaseProductName, databaseProductVersion, driverName, driverVersion);
        }
        else
        {
            salida = "Error: la conexión se encuentra cerrada.";
        }

        return salida;
    }

    /**
     * Proporciona info. sobre la sesión vigente y la base de datos abierta.
     *
     * @return La conexión establecida al servidor SQL o devuelve <i>'null'</i>
     * en caso de error.
     * @throws java.sql.SQLException
     */
    public Connection obtenerInfoSesion() throws SQLException
    {
        if(estadoOperativo.equals("inactivo"))
        {
          codigo_error = codigoError.errInactivo;  // estado operativo inactivo
          return null;
        }

        if(bdd_con.isClosed() == false)
        {
            return bdd_con;
        }

        return null;
    }

    /**
     *
     * @param fic
     * @return
     */
    public boolean existeFichero(String fic)
    {
        boolean estado;

        Path path = Paths.get(fic);
        estado = Files.isRegularFile(path, LinkOption.NOFOLLOW_LINKS);
        if(estado == false)
            codigo_error = codigoError.errArchivo;  // No se encuentra el archivo o no es un archivo regular

        return estado;
    }
}
