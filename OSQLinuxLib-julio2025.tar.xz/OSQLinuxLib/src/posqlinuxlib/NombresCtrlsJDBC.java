// Proyecto   : OSQLinuxLib
// Paquete    : posqlinuxlib
// Módulo     : NombresCtrlsJDBC.java
// Autor      : Octulio Biletán - Octubre de 2019.
// Descripción: Definir la clase NombresCtrlsJDBC.
//              Leer la documentación técnica doc-técnica.txt para más info.
// Ult. actualiz.: Marzo de 2025.
// Licencia   : GNU GPL ver. 3

/* NombresCtrlsJDBC.java
 *
 * Copyright (C) 2025 Eugenio Martínez.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Authors: Eugenio Martínez, https://t.me/octulioBiletan
 */

package posqlinuxlib;

/** <b>OSQLinuxLib.jar</b><br>
 * Clase NombresCtrlsJDBC.<br>
 * Con soporte para PostgreSQL, SQLite, MySQL, MariaDB, Oracle, Microsoft, indefinido.<br>
 * El nombre 'indefinido' indica que no posee un controlador JDBC asignado.
 * @author Octulio Biletán
 */
public class NombresCtrlsJDBC
{
    private final String psql_driver_jdbc = "org.postgresql.Driver";        // Para PostgreSQL
    private final String psql_url_jdbc    = "jdbc:postgresql://";           // URL para PostgreSQL
    private final String psql_puerto_jdbc = "5432";                         // Puerto para PostgreSQL

    private final String ssql_driver_jdbc = "org.sqlite.JDBC";		    // Para SQLite
    private final String ssql_url_jdbc    = "jdbc:sqlite:";		    // URL para SQLite
    private final String ssql_puerto_jdbc = "";				    // Puerto para SQLite

    // Versión anterior 5.1.25, "com.mysql.jdbc.Driver";
    // Versión probada: 9.2.0
    private final String msql_driver_jdbc = "com.mysql.cj.jdbc.Driver";     // Para MySQL
    private final String msql_url_jdbc    = "jdbc:mysql://";                // URL para MySQL
    private final String msql_puerto_jdbc = "3306";                         // Puerto para MySQL

    private final String masql_driver_jdbc = "org.mariadb.jdbc.Driver";     // Para MariaDB
    private final String masql_url_jdbc    = "jdbc:mariadb://";             // URL para MariaDB
    private final String masql_puerto_jdbc = "3306";                        // Puerto para MariaDB

    private final String osql_driver_jdbc = "oracle.jdbc.OracleDriver";     // Para Oracle OCI Driver
    private final String osql_url_jdbc    = "jdbc:oracle:";                 // URL para Oracle: "jdbc:oracle:oci:@myhost:1521:orcl"
    private final String osql_puerto_jdbc = "1521";                         // Puerto para Oracle

    private final String mssql_driver_jdbc = "com.microsoft.sqlserver.jdbc.SQLServerDriver";    // Para Microsoft
    private final String mssql_url_jdbc    = "jdbc:sqlserver://";           // URL para Microsoft SQL Server
    private final String mssql_puerto_jdbc = "1433";                        // Puerto para Microsoft SQL Server

    private final String isql_driver_jdbc = "indefinido.jdbc.Driver";	    // Para indefinido
    private final String isql_url_jdbc    = "jdbc:indefinido://";	    // URL para indefinido
    private final String isql_puerto_jdbc = "-1";			    // Puerto para indefinido

    /**
     *  La lista de controladores JDBC admitidos.
     */
    public final String []lista;

    /**
     * Constructor de la clase NombresCtrlsJDBC.
     */
    public NombresCtrlsJDBC() {
        this.lista = new String[]{ psql_driver_jdbc, ssql_driver_jdbc,
                                   msql_driver_jdbc, masql_driver_jdbc,
                                   osql_driver_jdbc, mssql_driver_jdbc,
                                   isql_driver_jdbc
                                 };
    }

// PostgreSQL <·············································>
    public String psqlControlador()
    {
        return psql_driver_jdbc;
    }

    public String psqlURL()
    {
        return psql_url_jdbc;
    }

    public String psqlPuerto()
    {
        return psql_puerto_jdbc;
    }

// SQLite <·················································>
    public String ssqlControlador()
    {
        return ssql_driver_jdbc;
    }

    public String ssqlURL()
    {
        return ssql_url_jdbc;
    }

    public String ssqlPuerto()
    {
        return ssql_puerto_jdbc;
    }

// MySQL <··················································>
    public String msqlControlador()
    {
        return msql_driver_jdbc;
    }

    public String msqlURL()
    {
        return msql_url_jdbc;
    }

    public String msqlPuerto()
    {
        return msql_puerto_jdbc;
    }

// MariaDB <················································>
    public String masqlControlador()
    {
        return masql_driver_jdbc;
    }

    public String masqlURL()
    {
        return masql_url_jdbc;
    }

    public String masqlPuerto()
    {
        return masql_puerto_jdbc;
    }

// Oracle SQL Server <·············································>
    public String osqlControlador()
    {
        return osql_driver_jdbc;
    }

    public String osqlURL()
    {
        return osql_url_jdbc;
    }

    public String osqlPuerto()
    {
        return osql_puerto_jdbc;
    }

// Microsoft SQL Server <·············································>
    public String mssqlControlador()
    {
        return mssql_driver_jdbc;
    }

    public String mssqlURL()
    {
        return mssql_url_jdbc;
    }

    public String mssqlPuerto()
    {
        return mssql_puerto_jdbc;
    }

// indefinido <·············································>
    public String isqlControlador()
    {
        return isql_driver_jdbc;
    }

    public String isqlURL()
    {
        return isql_url_jdbc;
    }

    public String isqlPuerto()
    {
        return isql_puerto_jdbc;
    }
}
