// Proyecto   : OSQLinuxLib
// Paquete    : pcomando
// Módulo     : bcComando.java
// Autor      : Octulio Biletán - Diciembre de 2024.
// Descripción: Definir la clase bcComando para gestionar la llamada al intérprete de comandos del S.O.
//              Leer la documentación técnica doc-técnica.txt para más info.
// Ult. cambio: Julio de 2025

/* bcComando.java
 *
 * Copyright (C) 2025 Eugenio Martínez.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Authors: Eugenio Martínez, https://t.me/octulioBiletan
 */

package pComando;

import java.io.IOException;
import java.lang.management.ManagementFactory;
import pConsola.Consola;

/**
 * Es una biblioteca de clase que sirve para ejecutar comandos internos y/o externos del S.O.<br>
 * <b>Ejemplo de uso:</b><br>
 * <code>&nbsp;&nbsp;&nbsp;bcComando comando = new bcComando();<br>
 * &nbsp;&nbsp;&nbsp;int estado = comando.shell("clear");</code>
 *
 * @author Octulio Biletán
 */
public class bcComando
{
    private int codigoSalida;
    private String com;
    private String arg_com;
    private Consola consola;

    /**
     * <code>bcComando()</code> inicializa las variables datos de la clase <code>bcComando</code>.
     */
    public bcComando()
    {
        String tmp;

        this.codigoSalida = 0;

        tmp = System.getenv("SHELL");
        if(tmp == null)
        {
            tmp = System.getenv("COMSPEC");
            if(tmp == null)
            {
              tmp = "DESCONOCIDO";
            }
            else
            {
                this.com = tmp;
                this.arg_com = "/c";
            }
        }
        else
        {
            this.com = tmp;

            if(this.com.isEmpty())
                this.com = "/bin/csh";  // Consultar /etc/shells

            this.arg_com = "-c";
        }

        this.consola = new Consola();
    }

    /**
     * <i>shell()</i> invoca al intérprete de comandos suministrado por el S.O para ejecutar sus órdenes internas,
     * como así también las aplicaciones binarias.<br><br>
     * <b>Ejemplo de uso:</b><br>
     * <pre><code>    bcComando comando = new bcComando();<br>
     *    int estado = comando.shell("echo 'Error encontrado.'");<br>
     *    System.out.printf("Código recibido: %d\n", estado);
     * </code></pre>
     * @param cmd El comando a transferir al intérprete de comandos.
     * @return int El código de salida devuelto por el intérprete de comandos.
     */
    public int shell(String cmd)
    {
        try
        {
            codigoSalida = new ProcessBuilder(com, arg_com, cmd).inheritIO().start().waitFor();
        }
        catch (IOException | InterruptedException ex)
        {
            consola.salidaError().println(ex.getMessage());
        }

        return codigoSalida;
    }

    /**
     * Devuelve el nombre del Sistema Operativo (S.O.) actual.<br>
     * Puede ser <b>linux</b>, <b>windows</b>, etc.
     * @return El nombre del S.O.
     */
    public String SistemaOperativo()
    {
	return (ManagementFactory.getOperatingSystemMXBean().getName()).toLowerCase();
    }
}
