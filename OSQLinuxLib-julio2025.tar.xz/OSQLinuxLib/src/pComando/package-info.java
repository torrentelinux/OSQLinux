// Proyecto   : OSQLinuxLib
// Paquete    : pComando
// Módulo     : package-info.java
// Autor      : Octulio Biletán - Marzo de 2025.
// Descripción: Contiene una breve información descriptiva sobre 'bcComando'.
//              Leer la documentación técnica doc-técnica.txt para más info.
// Ult. cambio: Julio de 2025.
// Licencia   : GNU GPL ver. 3

/* package-info.java
 *
 * Copyright (C) 2025 Eugenio Martínez.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Authors: Eugenio Martínez, https://t.me/octulioBiletan
 */

/**
 * <pre>Descripción del paquete</pre>
 * <p> Paquete pComando.<br>
 * Este paquete aún se encuentra en fase de desarrollo y prueba (Julio de 2025).<br><br>
 * <u>Developer Manager:</u> Eugenio Martínez.<br>
 * <u>GitHub:</u> https://github.com/torrentelinux/torrentarium/<br>
 * <u>Contacto:</u> https://t.me/octulioBiletan
 * </p>
 */
package pComando;
