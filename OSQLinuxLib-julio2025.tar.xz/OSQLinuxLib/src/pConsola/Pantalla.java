// Proyecto   : OSQLinuxLib
// Paquete    : pConsola
// Módulo     : Pantalla.java
// Autor      : Octulio Biletán - Octubre de 2024.
// Descripción: Definir la clase Pantalla.
//              Leer la documentación técnica doc-técnica.txt para más info.
// Ult. cambio: Marzo de 2025.

/* Pantalla.java
 *
 * Copyright (C) 2025 Eugenio Martínez.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Authors: Eugenio Martínez, https://t.me/octulioBiletan
 */

package pConsola;

import java.awt.Toolkit;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.jline.reader.impl.*;
import org.jline.terminal.*;

/**
 * Clase Pantalla.<br>
 * Gestiona la salida estándar de los datos hacia la pantalla de video de la
 * computadora.<br>
 * Permite la visualización de datos numéricos, líneas de textos y datos
 * alfanuméricos.<br>
 *
 * @author Octulio Biletán
 */
public class Pantalla
{
    /**
     * Definición del constructor de la clase Pantalla.
     */
    public Pantalla() { }

    /**
     * <b>errTexto</b> envía a la pantalla (consola de error) <i>'txt'</i> para
     * su tratamiento como mensaje de error.<br>
     *
     * @param txt Es la línea de textos a visualizar en la consola de error.<br>
     */
    public void errTexto(String txt)
    {
        System.err.println(txt);
        System.err.flush();
    }

    /**
     * textoLinea envía a la pantalla 'txt' para su visualización.<br>
     * Efectúa un avance de línea al final de la línea de textos.<br>
     *
     * @param txt Es la línea de textos a visualizar en pantalla.<br>
     */
    public void textoLinea(String txt)
    {
        System.out.println(txt);
    }

    /**
     * En cuanto a su utilidad, 'fmtLinea' es similar a 'printf'.<br>
     * <b>Ejemplo:</b>
     * <code>bcSQL database = new bcSQL(); Pantalla pantalla = new Pantalla();<br>
     * pantalla.fmtLinea("Versión del servidor SQL: %s\n",
     * database.version());</code><br>
     * @param fmt Especificación del formato de texto a emplear.
     * @param args Argumentos que acompañan a la especificación del formato.
     * @see java.io.PrintStream#printf(java.lang.String, java.lang.Object...)
     */
    public void fmtLinea(String fmt, Object... args)
    {
        System.out.printf(fmt, args);
    }

    /**
     * avLinea efectúa un avance de línea del cursor sobre la pantalla.<br>
     */
    public void avLinea()
    {
        System.out.println();
    }

    /**
     * Efectúa una pausa en la ejecución de la aplicación durante un tiempo
     * 'segs' expresado en segundos.
     *
     * @param segs Es la cantidad de tiempo en segundos que hace una pausa.
     * @throws InterruptedException Lanza una excepción por interrupción.
     */
    public void esperar(int segs) throws InterruptedException
    {
        TimeUnit.SECONDS.sleep(segs);
    }

    /**
     * Borra toda la pantalla y coloca el cursor en la esquina superior
     * izquierda.<br>
     */
    public void limpiar()
    {
        // Si la var. de entorno 'Navegador' está definida es porque ha sido
        // llamado este método desde algún cliente de navegación de páginas webs.
        // Caso contrario, su valor es nulo.
        if (System.getenv("Navegador") == null) {
            try {
                Terminal terminal = TerminalBuilder.terminal();
                LineReaderImpl pantallaVisual = new LineReaderImpl(terminal);

                pantallaVisual.clearScreen();
                pantallaVisual.flush();
                terminal.flush();
            } catch (IOException ex) {
                System.err.println("Error [limpiar()]: " + ex.getMessage());
            }

        }
        else
            System.out.println("\033[2J");
    }
    
    /**
     * Emite un pitido por el altavoz de la computadora.<br>
     * Es similar a <i>'beep()'</i> de la biblioteca de clases
     * 'java.awt.Toolkit'.
     */
    public void bip()
    {
        // Si la var. de entorno 'Navegador' está definida es porque ha sido
        // llamado este método desde algún cliente de navegación de páginas webs.
        // Caso contrario, su valor es nulo.
        if (System.getenv("Navegador") == null) {
            Toolkit.getDefaultToolkit().beep();
        }
        else
        {
            System.out.println("\007");
        }
    }
}
