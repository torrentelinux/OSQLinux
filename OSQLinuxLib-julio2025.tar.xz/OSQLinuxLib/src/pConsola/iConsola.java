// Proyecto   : OSQLinuxLib
// Paquete    : pConsola
// Módulo     : iConsola.java
// Autor      : Octulio Biletán - Diciembre de 2024.
// Descripción: Definir la interfaz iConsola.
//              Leer la documentación técnica doc-técnica.txt para más info.
// Ult. cambio: Julio de 2025.

/* iConsola.java
 *
 * Copyright (C) 2025 Eugenio Martínez.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Authors: Eugenio Martínez, https://t.me/octulioBiletan
 */

package pConsola;

/**
 * Interfaz Consola de E/S.
 * @author Octulio Biletán
 */
public abstract interface iConsola
{
    /**
     * Nº de versión de la interfaz iConsola.
     */
    public final double VERSION = 1.0725;

    /**
     * Nombre de la interfaz iConsola.
     */
    public final char NOMBRE[] = {'i','C','o','n','s','o','l','a'};

    /**
     * Devuelve el nº de versión de la interfaz iConsola.
     * @return nº de versión.
     */
    public abstract double ver();

    /**
     * Devuelve el nombre de la interfaz iConsola.
     * @return nombre de la interfaz.
     */
    public abstract char[] nombre();
}
