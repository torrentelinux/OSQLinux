// Proyecto   : OSQLinuxLib
// Paquete    : pConsola
// Módulo     : Consola.java
// Autor      : Octulio Biletán - Diciembre de 2024.
// Descripción: Definir la clase Consola a partir de la interfaz iConsola.
//              Leer la documentación técnica doc-técnica.txt para más info.
// Ultima actualización: Marzo de 2025.

/* Consola.java
 *
 * Copyright (C) 2025 Eugenio Martínez.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Authors: Eugenio Martínez, https://t.me/octulioBiletan
 */

package pConsola;

import java.io.PrintStream;

/**
 * Clase Consola de E/S estándar.
 * @author Octulio Biletán
 */
public final class Consola implements iConsola
{
    private final Pantalla consola_pnt;
    private final PrintStream consola_salidaError;
    private final PrintStream consola_salidaEstandar;

    /**
     * Constructor de la clase Consola.
     */
    public Consola()
    {
        this.consola_pnt = new Pantalla();
        this.consola_salidaError = System.err;
        this.consola_salidaEstandar = System.out;
    }

    /**
     *
     * @return
     */
    public Pantalla pantalla()
    {
        return consola_pnt;
    }

    /**
     * Devuelve el canal estándar de errores para la visualizacion de mensajes por pantalla.
     * @return El canal estándar de errores.
     */
    public PrintStream salidaError()
    {
        return consola_salidaError;
    }

    public PrintStream salidaStd()
    {
        return consola_salidaEstandar;
    }

    /**
     * Devuelve el nº de versión de la interfaz iConsola.
     * @return nº de versión.
     */
    @Override
    public double ver()
    {
        return iConsola.VERSION;
    }

    /**
     * Devuelve el nombre de la interfaz iConsola.
     * @return nombre de la interfaz.
     */
    @Override
    public char[] nombre()
    {
        return iConsola.NOMBRE;
    }

    /**
     * Devuelve el nombre y el nº de versión de la interfaz de clase iConsola.<br>
     * La interfaz de clase iConsola forma parte del paquete pConsola.<br>
     * <b>Ejemplo de uso:</b> consola.pantalla().textoLinea(consola.info_iConsola());<br>
     * @return El nombre y el nº de versión de la interfaz de clase iConsola.
     */
    public String info_iConsola()
    {
        String version_iConsolaLib;

        version_iConsolaLib = String.format("%s ver. %.4f", String.valueOf(Consola.NOMBRE), Consola.VERSION);
        return version_iConsolaLib;
    }

    /**
     * Devuelve el nombre y el nº de versión de la clase Consola.<br>
     * La clase Consola forma parte del paquete pConsola.<br>
     * <b>Ejemplo de uso:</b> consola.pantalla().textoLinea(consola.infoConsola());<br>
     * @return El nombre y el nº de versión de la clase Consola.
     */
    public String infoConsola()
    {
        String info_ConsolaLib;

        info_ConsolaLib = String.format("%s ver. %.4f", getClass().getSimpleName(), Consola.VERSION);
        return info_ConsolaLib;
    }

    /**
     * Devuelve una breve descripción acerca de la clase <code>Consola</code>.<br>
     * @return La descripción de la clase <code>Consola</code>.
     */
    public String descripcionConsola()
    {
        return "Biblioteca de clase para la E/S estándar de datos.";
    }

    /**
     * Es similar a la función <code>puts()</code> de <i>stdio.h</i> en el lenguaje <b>C</b>.
     * @param s El texto a visualizar en el dispositivo asociado a la salida estándar del S.O.
     * @return El nº de caracteres impresos en el dispositivo de salida.<br>
     * Devuelve EOF en caso de error.
     */
    @SuppressWarnings("unused")
    public int puts(String s)
    {
        if(s == null)
        {
            int EOF = -1;
            return EOF;
        }

        System.out.println(s);
        return s.length();
    }
}
