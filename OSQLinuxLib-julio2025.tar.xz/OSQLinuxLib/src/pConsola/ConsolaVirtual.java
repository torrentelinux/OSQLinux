// Proyecto   : OSQLinuxLib
// Paquete    : pConsola
// Módulo     : ConsolaVirtual.java
// Autor      : Octulio Biletán - Diciembre de 2024.
// Descripción: Definir la clase ConsolaVirtual.
//              Leer la documentación técnica doc-técnica.txt para más info.
// Ult. cambio: Marzo de 2025.

/* ConsolaVirtual.java
 *
 * Copyright (C) 2025 Eugenio Martínez.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Authors: Eugenio Martínez, https://t.me/octulioBiletan
 */

package pConsola;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * Consola Virtual: consiste en almacenar la salida de datos en la memoria
 * mediante una secuencia de caracteres (string).
 * @author Octulio Biletán
 */
public final class ConsolaVirtual
{
	private boolean      esta_abierta;
	private StringWriter string_writer;
	private PrintWriter  consola_virtual;

    /**
     * ConsolaVirtual (constructor).<br>
     * Inicializa la clase ConsolaVirtual.
     */
    @SuppressWarnings("unused")
    public ConsolaVirtual()
    {
	string_writer = null;
	consola_virtual = null;
	esta_abierta = false;
    }

    /**
     * Abre la consola virtual para las operaciones de E/S.
     */
    public void abrir()
    {
	if(esta_abierta)
	  return;

	string_writer = new StringWriter();
	consola_virtual = new PrintWriter(string_writer);
	esta_abierta = true;
    }

    /**
     * Cierra la consola virtual para las operaciones de E/S.
     */
    public void cerrar()
    {
	if(esta_abierta)
	{
	    consola_virtual.flush();
	    consola_virtual.close();
	    esta_abierta = false;
	}
    }

    /**
     * textoSalida
     * @return Devuelve el texto almacenado en memoria.
     */
    public String textoSalida()
    {
        if(esta_abierta)
        {
            return string_writer.toString();
        }

        return "";
    }

    /**
     * consolaVirtual
     * @return Devuelve una instancia de clase PrintWriter.
     */
    public PrintWriter consolaVirtual()
    {
	if(esta_abierta)
	{
	    return consola_virtual;
	}

	return null;
    }
}
