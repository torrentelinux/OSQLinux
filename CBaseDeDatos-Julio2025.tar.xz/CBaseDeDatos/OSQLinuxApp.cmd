@echo off
java.exe -jar .\dist\CBaseDeDatos.jar
pause
