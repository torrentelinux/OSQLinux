// Proyecto   : CBaseDeDatos
// Paquete    : osqlinuxapp
// Módulo     : package-info.java
// Autor      : Octulio Biletán - Marzo de 2025.
// Descripción: Contiene una breve información descriptiva sobre 'osqlinuxapp'.
//              Leer la documentación técnica doc-técnica.txt para más info.
// Ult. cambio: Julio de 2025.
// Licencia   : GNU GPL ver. 3

/* package-info.java
 *
 * Copyright (C) 2025 Eugenio Martínez.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Authors: Eugenio Martínez, https://t.me/octulioBiletan
 */

/**
 * <pre>Descripción del paquete</pre>
 * <p> Este paquete contiene el programa principal 'OSQLinuxApp' con su método main().<br>
 * Para establecer un enlace de comunicación con el servidor SQL se utilizará el archivo <code>CBaseDeDatos/credenciales.properties,</code><br>
 * este contiene todos los datos necesarios para abrir una sesión con la cuenta del usuario y así poder efectuar las operaciones de E/S con la base de datos.<br>
 * El usuario puede personalizar los contenidos que están allí. Por ejemplo puede cambiar el nombre de la cuenta y su contraseña.<br>
 * Para más información sobre esta biblioteca leer en la "Documentación técnica del proyecto CBaseDeDatos".<br>
 * Se encuentra aquí: <a href="../../../Doc-t%C3%A9cnica-bcSQL.html#acp">Doc-técnica-bcSQL.html#acp</a><br><br>
 * <u>Developer Manager:</u> Eugenio Martínez.<br>
 * <u>GitHub:</u> https://github.com/torrentelinux/torrentarium/<br>
 * <u>Contacto:</u> https://t.me/octulioBiletan<br>
 * </p>
 */
package osqlinuxapp;
