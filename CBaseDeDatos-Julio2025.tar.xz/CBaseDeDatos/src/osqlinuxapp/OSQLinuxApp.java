// Proyecto   : CBaseDeDatos
// Paquete    : osqlinuxapp
// Programa   : OSQLinuxApp.java
// Autor      : Octulio Biletán - Octubre de 2019.
// Propósito  : Definir un programa llamado OSQLinuxApp (Octulio,SQL,Linux,Application) para
//	        probar la biblioteca de clase bcSQL (biblioteca de clase SQL).
// Observac.  : La clase principal que contiene a 'main()' es 'osqlinuxapp.OSQLinuxApp'
// Ult. cambio: Julio de 2025.
// Licencia   : GNU GPL ver. 3

/* OSQLinuxApp.java
 *
 * Copyright (C) 2025 Eugenio Martínez.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Authors: Eugenio Martínez, https://t.me/octulioBiletan
 */

package osqlinuxapp;

import com.sun.jna.Pointer;
import java.io.IOException;
import java.net.InetAddress;
import java.sql.SQLException;
import libme.Libme;
import libme.Libme.Stdio;
import libme.Libme.Stdlib;
import libme.Libme.Unistd;
import pConsola.Consola;
import pConsola.Pantalla;
import posqlinuxlib.bcSQL;
import posqlinuxlib.nombreCtrlJDBC;

/**
 * Contiene la definición de la clase <b><code>OSQLinuxApp</code></b>.<br>
 * <b>OSQLinuxApp</b> prueba la biblioteca de clases <b>bcSQL</b> estableciendo una conexión <i>JDBC</i> al servidor local de SQL.<br>
 * Se procederá a crear una base de datos llamada 'Agenda' con una tabla llamada 'Contactos'.
 */
public class OSQLinuxApp
{
    private final Pantalla pnt;

    /**
     * Constructor de la clase OSQLinux.
     * Inicializa la mencionada clase.
     */
    public OSQLinuxApp()
    {
        this.pnt = new Pantalla();
    }

    /**
     * Devuelve la instancia de la clase Pantalla.
     * @return La instancia de la clase Pantalla.
     * @see pConsola.Pantalla
     */
    public Pantalla salida()
    {
        return this.pnt;
    }

    /**
     * Entrada secundaria a la aplicación.
     *
     * @return Devuelve un valor entero al método invocante.
     * @throws java.io.IOException Lanza una excepción por otros tipos de errores.
     * @throws java.lang.InterruptedException Lanza una excepción por interrupción.
     * @throws java.sql.SQLException Lanza una excepción SQL.
     */
    public static int main() throws IOException, InterruptedException, SQLException
    {
	// Bloque Define vars.
		boolean resultado = false;
		int codigo = 0;
		String bdAgenda = "Agenda";
		String tbContactos = "Contactos";
		String codigoSQL = "";
		String usrCorreo = "";
		String nombreEquipo = "";
		Consola consola = new Consola();
		bcSQL database = new bcSQL();
                Libme soporte = new Libme();
	// Bloque Final.

        consola.pantalla().limpiar();
        consola.pantalla().bip();

        consola.puts("Aplicación " + OSQLinuxApp.class.getCanonicalName());

        consola.pantalla().textoLinea(database.nombre_bcSQL() + " ver. " + database.version_bcSQL() + " * serie " + database.serie_bcSQL());
        consola.pantalla().textoLinea(database.descripcion_bcSQL());

        consola.pantalla().textoLinea(consola.infoConsola());
        consola.pantalla().textoLinea(consola.descripcionConsola());
        consola.puts("");

	// Se identifica al S.O. vigente
        consola.puts("S.O.: " + database.productoSO());

        // Consulta el nombre y la IP local del equipo
        nombreEquipo = InetAddress.getLocalHost().getCanonicalHostName();
        consola.puts("Equipo: " + nombreEquipo);
        consola.puts("IP: " + InetAddress.getLocalHost().getHostAddress());

        // Consulta por la consola vigente
        if(database.versionSO().contains("Linux"))
            consola.puts("Tipo de consola de textos activa: " + System.getenv("TERM"));
	else
	{
	    consola.puts("Tipo de consola de textos activa: ");
	    consola.puts("  1º caso: " + System.getenv("ShellId"));  // PowerShell  -- get-variable
	    consola.puts("  2º caso: " + System.getenv("COMSPEC"));  // CMD -- set
	    consola.puts("  3º caso: " + System.getenv("TERM"));     // cygwin -- env
	}

        consola.pantalla().avLinea();

        // Paso 1º: leer las credenciales desde el archivo credenciales.properties
        try
        {
            consola.puts("Iniciando la conexión al servidor, aguarde un momento...");

            resultado = database.solicitar_ingreso("/base/seguridad/agenda/credenciales");
            if(resultado)
            {
                consola.pantalla().textoLinea("\n·Conexión aceptada al servidor: " + database.obtenerNombreServidor());
            }
            else
            {
                consola.salidaError().printf("\n·Error en la solicitud de ingreso: %d\n", database.ultimoError());
                return 1;			// retorna al S.O.
            }
        }
        catch(IOException | InterruptedException e)	// Falló la entrada al servidor SQL
        {
            consola.pantalla().errTexto("Falló la solicitud de ingreso al servidor.");
            return 1;				// retorna al S.O.
        }

        // Paso 2º: comenzar a operar sobre el servidor SQL y la base de datos.

        consola.pantalla().avLinea();
        consola.pantalla().textoLinea("Estado operativo de la aplicación: " + database.condicionOperativa());

        // Muestra información sobre el servidor SQL
        consola.pantalla().fmtLinea("Versión del servidor SQL: %s\n", database.version());
        consola.pantalla().textoLinea(database.controladorInfo());

        if(database.nombreConector().compareTo(nombreCtrlJDBC.postgresql) == 0)
        {
            consola.pantalla().textoLinea("\n·Cuentas de usuarios");
            consola.pantalla().textoLinea(database.usuarios());

            consola.pantalla().textoLinea("·Bases de Datos almacenadas:");
            consola.pantalla().textoLinea(database.listarBD());
        }
        else
            consola.pantalla().avLinea();

        // Elimina/borra la base de datos Agenda
        // En Postgresql, el nombre de la base de datos debe contener minúsculas
        resultado = database.borrar(bdAgenda.toLowerCase());
        if(resultado)
        {
            consola.pantalla().textoLinea("·Base de datos '" + bdAgenda + "' borrada.");
        }
	else
	{
	    consola.pantalla().errTexto("Falló la eliminación de la base de datos.");
	    codigo = 2;				// retorna al S.O.
	}

        // Crea la base de datos Agenda
        resultado = database.crear(bdAgenda);
        if(resultado)
	{
            consola.pantalla().textoLinea("·Base de datos '" + bdAgenda + "' creada.");
        }
	else
	{
            consola.pantalla().errTexto("Falló la creación de la base de datos.");
            codigo = 3;				// retorna al S.O.
        }

        consola.pantalla().avLinea();

        // Abre la base de datos Agenda
        resultado = database.abrir(bdAgenda.toLowerCase());
        if(resultado)
	{
            consola.pantalla().textoLinea("·Base de datos " + database.nombre() + " abierta.");
        }
	else
	{
            consola.pantalla().errTexto("Falló la apertura de la base de datos.");
            return 4;  // devuelve al S.O.
        }

        consola.pantalla().textoLinea("· Catálogo vigente: " + database.obtenerInfoSesion().getCatalog());
        consola.pantalla().textoLinea("· Usuario vigente: " + database.obtenerInfoSesion().getMetaData().getUserName());
        consola.puts("· URL vigente: " + database.obtenerInfoSesion().getMetaData().getURL());

        consola.pantalla().avLinea();
        consola.pantalla().esperar(2);

	// ************************************************
            // Crea la tabla Contactos y tiene la sig. estructura:
            // Codigo(int), NombreCompleto(char 64), Correo_e(char 320)
            // Postgresql: va con comillas; MySQL: va sin comillas
            resultado = database.tabla.crear(tbContactos, "Codigo integer NOT NULL, NombreCompleto varchar(64), Correo_e varchar(320)");
            if(resultado)
            {
                consola.pantalla().textoLinea("·Tabla " + database.tabla.nombre() + " creada.");
            }
            else
            {
                consola.pantalla().errTexto("Falló la creación de la tabla.");
                codigo = 5;  // devuelve al S.O.
            }

            consola.pantalla().avLinea();

            // Agregar nuevos datos a la tabla Contactos
            // Postgresql: va con comillas--> resultado = database.tabla.agregar("\"Contactos\"", "\"Codigo\", \"NombreCompleto\", \"Correo_e\"", "100, 'operador', 'operador@localhost'");
            int nrofila = 1;
            String campos_contactos = "Codigo, NombreCompleto, Correo_e";
            String []filas = { "300, 'observador',   'observador@localhost.localdomain'",
                               "200, 'operador',     'operador@localhost.localdomain'",
                               "100, 'supervisor',   'supervisor@localhost.localdomain'",
                               "30,  'fiscalizador', 'fiscalizador@localhost.localdomain'",
                               "25,  'auditor',      'auditor@localhost.localdomain'",
                               "20,  'inspector',    'inspector@localhost.localdomain'",
                               "15,  'interventor',  'interventor@localhost.localdomain'",
                               "10,  'coordinador',  'coordinador@localhost.localdomain'",
                               "5,   'administrador', 'administrador@localhost.localdomain'",
                               "0,   '',''"  // última fila, actúa como control de final de datos
                             };

            for(String fila : filas)
            {
                resultado = database.tabla.agregar(tbContactos, campos_contactos, fila);
                if(resultado)
                {
                    consola.pantalla().textoLinea("·Tabla " + database.tabla.nombre() + ", fila "+ nrofila + " actualizada.");
                }
                else
                {
                    consola.pantalla().errTexto("Falló la actualización de la tabla.");
                    codigo = 6;  // devuelve al S.O.
                }

                nrofila++;
            }

	    consola.pantalla().avLinea();
	    consola.pantalla().esperar(2);

            // Muestra en pantalla todo el contenido de la tabla Contactos
            consola.pantalla().textoLinea("Contenido de la tabla " + database.tabla.nombre());

            // Postgresql: va con comillas--> resultado = database.tabla.mostrarTodo("\"Contactos\"");
            resultado = database.tabla.mostrarTodo(tbContactos);
            if(resultado)
            {
                consola.pantalla().textoLinea("·Listado completo efectuado.");
            }
            else
            {
                consola.pantalla().errTexto("Falló el listado completo de la tabla.");
                codigo = 7;  // devuelve al S.O.
            }

            consola.pantalla().avLinea();

	    // Compone el nuevo correo-e para la cuenta 'operador' a partir del nombre y sufijo DNS del equipo local
	    usrCorreo = soporte.componerCorreoElectronico("operador", "", "");

            // Modificar el correo-e del "operador" mediante la instrucción UPDATE de SQL
            consola.puts("·Modifica el correo-e de la cuenta operador.");
	    codigoSQL = "update Contactos set Correo_e = '" + usrCorreo + "' where NombreCompleto = 'operador'";

            String tmp = database.tabla.ejecutarSQL(codigoSQL);
            if(database.tabla.hayError() == false)
            {
                consola.puts( database.tabla.ejecutarSQL("select * from Contactos where NombreCompleto = 'operador'"));
                consola.puts("·Operación exitosa.");
            }
            else
            {
                consola.salidaError().print(tmp);
                consola.salidaError().println("Código: " + database.tabla.codigoError());
                codigo = 8;  // devuelve al S.O.
            }

            consola.pantalla().avLinea();
	    consola.pantalla().esperar(2);
	// ************************************************

        if(database.nombreConector().compareTo(nombreCtrlJDBC.postgresql) == 0)
        {
            // Procede a examinar la cuenta 'octulio' y modifica su contraseña
            String usuario = "octulio";

            // ¿ existe la cuenta ?
            if(database.existeCuenta(usuario) == false)
            {
                // crea la cuenta
                if(database.crearCuenta(usuario))
                    consola.puts("La cuenta ha sido creada: " + usuario);
                else
                    consola.puts("La cuenta no ha sido creada: " + usuario);
            }

            boolean aup = database.cambiarClave(usuario, "poiu");
            if(aup == true)
            {
                consola.pantalla().textoLinea("Contraseña cambiada a " + usuario);
            }
            else
            {
                consola.pantalla().textoLinea("Sin cambios en la contraseña de <" + usuario + ">");
            }
        }

        consola.pantalla().esperar(3);

        // Cierra la conexión a la base de datos
        resultado = database.cerrar();
        if(resultado)
        {
            consola.pantalla().textoLinea("·Base de datos cerrada.");
        }
        else
        {
            consola.pantalla().errTexto("Falló el cierre de la base de datos.");
            codigo = 9;  // devuelve al S.O.
        }

        consola.pantalla().textoLinea("Finalizado.");
        return codigo;
    }

    /**
     * Entrada principal a la aplicación.
     *
     * @param args Los argumentos que vienen de la línea de orden (desde la
     * consola de textos).
     * @throws java.io.IOException Lanza una excepción por E/S de datos.
     * @throws java.lang.InterruptedException Lanza una excepción por interrupción en aplicación.
     * @throws java.sql.SQLException Lanza una excepción SQL genérica.
     */
    public static void main(String []args) throws IOException, InterruptedException, SQLException
    {
        OSQLinuxApp miAplicacion = new OSQLinuxApp();
        Libme soporte = new Libme();
        Stdio stdio = null;
        Unistd unistd = null;
        Stdlib stdlib = null;

        stdio = soporte.vincular(stdio);
        stdlib = soporte.vincular(stdlib);
        unistd = soporte.vincular(unistd);

        stdio.puts("*");
        stdlib.fflush(Pointer.NULL);
        Thread.sleep(1000);

        int codigo = main();
        miAplicacion.salida().fmtLinea("Devuelve %d.\n", codigo);

        stdio.puts("**");
        if(codigo != 0)
        {
            soporte.regresarSO(codigo);  // retorna al S.O. con código de salida
        }
    }
}
