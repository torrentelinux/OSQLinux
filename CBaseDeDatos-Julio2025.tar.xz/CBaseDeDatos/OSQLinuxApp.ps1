java.exe -jar .\dist\CBaseDeDatos.jar
Read-Host -Prompt "Presione tecla [Intro] para continuar..."
