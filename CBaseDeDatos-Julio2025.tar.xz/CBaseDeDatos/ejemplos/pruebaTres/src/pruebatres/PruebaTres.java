// Proyecto : pruebaTres
// Paquete  : pruebatres
// Programa : PruebaTres.java
// Autor    : Octulio Biletán - Enero de 2025.
// Propósito: Definir un programa llamado pruebaTres para
//            probar la biblioteca de clases bcSQL (biblioteca de clases SQL).
// Obs.     : La clase principal que contiene a 'main()' es 'pruebatres.PruebaTres'.
// Ultima actualización: Julio de 2025.
// Licencia: GNU GPL ver. 3

/* PruebaTres.java
 *
 * Copyright (C) 2025 Eugenio Martínez.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Authors: Eugenio Martínez, https://t.me/octulioBiletan
 */

package pruebatres;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import pConsola.Consola;
import pConsola.Pantalla;
import posqlinuxlib.bcCredenciales;
import posqlinuxlib.nombreCtrlJDBC;

/**
 * Clase PruebaTres
 * @author Octulio Biletán
 */
public class PruebaTres
{
    private final Consola consola;

    /**
     * Definición del constructor de la clase PruebaDos.
     */
    public PruebaTres()
    {
        this.consola = new Consola();
    }

    /**
     * Devuelve el id. de la salida estándar definido como System.out.
     * @return El id. de la salida estándar.
     */
    public PrintStream cout()
    {
	return consola.salidaStd();
    }

    /**
     * Invoca al método System.exit(exit_code) para retornar al S.O.
     *
     * @param exit_code Código de salida que se entrega al S.O.
     */
    public void returnOS(int exit_code)
    {
	System.exit(exit_code);
    }

    /**
     * Invoca a vntPruebaTres.
     * @return Devuelve 0 si todo ha ido bien sino cualquier otro valor indicando que ha fallado.
     */
    public int invocar()
    {
        String fcredenciales = "/base/seguridad/negocio/credenciales";
        Pantalla pnt = new Pantalla();

        // Muestra la ventana principal
        vntPruebaTres.entrada();

        pnt.limpiar();
        pnt.bip();

        // Borra el area de textos de la ventana
        vntPruebaTres.limpiar();

        vntPruebaTres.textoLinea("Aplicación 'pruebaTres'");

        vntPruebaTres.textoLinea("<Seguridad>\nLeyendo sus credenciales de entrada, aguarde un momento...");
        vntPruebaTres.textoLinea("Su credencial: " + fcredenciales);

        // Proceder a leer credenciales.properties
	bcCredenciales credenciales = new bcCredenciales();
        credenciales.abrir(fcredenciales);

        if(credenciales.hayError())
        {
            pnt.bip();

            String msj;
            msj = "<ERROR> en " + credenciales.nombre() + "\n" + credenciales.leerError();
            JOptionPane.showMessageDialog(vntPruebaTres.getWindows()[0].getMostRecentFocusOwner(), msj, "Aviso", JOptionPane.ERROR_MESSAGE);

            return 1;  // No puede continuar y devuelve el código de salida al método invocante
        }

        try {
            pnt.esperar(2);
        } catch (InterruptedException ex) {
            Logger.getLogger(PruebaTres.class.getName()).log(Level.SEVERE, null, ex);
        }

        if(credenciales.condicionOperativa().equals("activo"))
        {
            vntPruebaTres.textoLinea("<Seguridad>\nAcceso concedido.");
        }
        else
        {
            vntPruebaTres.textoLinea("<Seguridad>\nAcceso denegado.");
            vntPruebaTres.errorMensaje("Saliendo de la aplicación...");
            
            return 2;  // No puede continuar y devuelve el código de salida al método invocante
        }

        // Procede a leer el campo conectividad y tomar el nombre del controlador JDBC
	nombreCtrlJDBC nc_jdbc = credenciales.leer("conectividad");
        
        String []dato = new String[1];
        dato[0] = "servidor";
        credenciales.leer(dato);

        vntPruebaTres.textoLinea("Controlador JDBC requerido: " + nc_jdbc);
        vntPruebaTres.textoLinea("Servidor: " + dato[0]);
        vntPruebaTres.textoLinea("Tarea terminada.");
        
        credenciales.cerrar();
        return 0;
    }

    /**
     * Entrada principal.
     * @param args Los argumentos que vienen de la línea de comandos.
     */
    public static void main(String[] args) 
    {
        int codigo;
        PruebaTres miAplicacion = new PruebaTres();

        codigo = miAplicacion.invocar();

        miAplicacion.cout().printf("Devuelve %d.\n", codigo);

        if(codigo != 0)
        {
            miAplicacion.returnOS(codigo);  // retorna al S.O.
        }
    }
}
