@echo off
java.exe -jar .\dist\pruebaDos.jar
pause
