// Proyecto : CBaseDeDatos
// Paquete  : pruebados
// Programa : PruebaDos.java
// Autor    : Octulio Biletán - Diciembre de 2024.
// Propósito: Definir un programa llamado pruebaDos para
//            probar la biblioteca de clases bcSQL (biblioteca de clases SQL).
// Obs.     : La clase principal que contiene a 'main()' es 'pruebados.PruebaDos'.
// Ultima actualización: Julio de 2025.
// Licencia: GNU GPL ver. 3

/* PruebaDos.java
 *
 * Copyright (C) 2025 Eugenio Martínez.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Authors: Eugenio Martínez, https://t.me/octulioBiletan
 */

package pruebados;
// ----------------
import java.io.*;
import java.sql.*;
import pConsola.Consola;
import pConsola.Pantalla;
import posqlinuxlib.bcSQL;
import posqlinuxlib.nombreCtrlJDBC;

/**
 * Definición de la clase pruebaDos.
 */
public class PruebaDos
{
    private final Consola consola;

    /**
     * Definición del constructor de la clase PruebaDos.
     */
    public PruebaDos()
    {
	this.consola = new Consola();
    }

    /**
     * Devuelve el id. de la salida estándar definido como System.out.
     * @return El id. de la salida estándar.
     */
    public PrintStream cout()
    {
	return consola.salidaStd();
    }

    /**
     * Invoca al método System.exit(exit_code) para retornar al S.O.
     *
     * @param exit_code Código de salida que se entrega al S.O.
     */
    public void returnOS(int exit_code)
    {
	System.exit(exit_code);
    }

    /**
     * Entrada secundaria a la aplicación.
     *
     * @return Devuelve un valor entero al método invocante.
     * @throws java.io.IOException Lanza una señal causada por operaciones de E/S.
     * @throws java.lang.InterruptedException Lanza una señal de interrupción.
     * @throws java.sql.SQLException Lanza una señal causada por la base de datos SQL.
     */
    public static int main() throws IOException, InterruptedException, SQLException
    {
        boolean resultado;
        int codigo = 0;
        String bdAgenda = "agenda";
        String tablaContactos = "\"Contactos2025\"";
        String campoCodigo = "\"Codigo\"";
        Consola consola = new Consola();
        bcSQL database = new bcSQL();
        Pantalla pnt;    // pantalla
        PrintStream se;  // salida estándar (System.out)

        pnt = new Pantalla();
        se = consola.salidaStd();

        pnt.limpiar();
        pnt.bip();

        pnt.textoLinea("Aplicación " + pruebados.PruebaDos.class.getCanonicalName() +
                                      " corriendo en S.O. " + database.productoSO());

        // Paso 1º: registrar el controlador JDBC que se quiere utilizar para iniciar
        // las operaciones de E/S en el servidor SQL.
        nombreCtrlJDBC nc_jdbc = nombreCtrlJDBC.postgresql;

        resultado = database.registrar(nc_jdbc);
        if(resultado == false)
	{
	    pnt.errTexto("<AVISO> El controlador JDBC " + nc_jdbc.toString() + " no se encuentra debidamente registrado.");
	}

        try  // Paso 2º: leer las credenciales desde el archivo credenciales.properties
        {
            pnt.textoLinea("Iniciando la conexión al servidor, aguarde un momento...");

            // Las credenciales se encuentran en /base/seguridad/agenda/credenciales.properties
            resultado = database.solicitar_ingreso("/base/seguridad/agenda/credenciales");
            if(resultado)
            {
                pnt.textoLinea("\n·Conexión aceptada al servidor: " + database.obtenerNombreServidor());
            }
            else
            {
                consola.salidaError().printf("\n·Error en '%s'. Código: %d\n", database.nombreFicCredenciales(), database.ultimoError());
                return 1;			// retorna al S.O.
            }
        }
        catch(IOException | InterruptedException e)	// Falló la entrada al servidor SQL
        {
            pnt.errTexto("Falló la solicitud de ingreso al servidor.");
            return 1;					// retorna al S.O.
        }

        pnt.avLinea();
        pnt.textoLinea("Estado operativo de la aplicación: " + database.condicionOperativa());

        // Muestra información sobre el servidor SQL
        pnt.fmtLinea("Versión del servidor SQL: %s\n", database.version());
        pnt.textoLinea(database.controladorInfo());

        pnt.textoLinea("·Bases de Datos almacenadas:");
        pnt.textoLinea(database.listarBD());

        // Establece el estilo de la hora y fecha a ISO.
        // En este caso es una sentencia válida para PostgreSQL.
        String cmd = "set datestyle to iso,dmy";
        String tmp = database.tabla.ejecutarSQL(cmd);
        if(!tmp.contains("0"))
        {
            pnt.errTexto("Falló la ejecución del comando SQL: " + cmd);
            codigo = 8;  // puede continuar a pesar del error registrado 
        }

        pnt.esperar(2);

        // Lee el tiempo actual del servidor SQL
        cmd = "select now()";
        se.print("Reloj del servidor: ");
        se.println(database.tabla.ejecutarSQL(cmd));

        // Modifica los atributos de la base de datos Agenda
        resultado = database.modificar(bdAgenda, "with connection limit -1");
        if(resultado)
        {
            pnt.textoLinea("·La base de datos " + database.nombre() + " ha sido modificada.");
        }
        else
        {
            pnt.errTexto("Falló la modificación de la base de datos.");
            codigo = 7;  // puede continuar a pesar del error registrado
        }

        pnt.avLinea();
        pnt.esperar(2);

        // ---------> Abre la base de datos Agenda <---------
        resultado = database.abrir(bdAgenda);
        if(resultado)
        {
            pnt.textoLinea("·Base de datos " + database.nombre() + " abierta.");
        }
        else
        {
            pnt.errTexto("Falló la apertura de la base de datos.");
            return 1;				// retorna al S.O.
        }

        Connection sqlconexion;

        sqlconexion = database.obtenerInfoSesion();

        pnt.textoLinea("·Catálogo vigente: " + sqlconexion.getCatalog());
        pnt.textoLinea("·Usuario vigente: " + sqlconexion.getMetaData().getUserName());

        pnt.avLinea();
        pnt.esperar(2);

        // (Alta) Agrega nuevos datos a la tabla Contactos: tabla, campos, datos
        resultado = database.tabla.agregar( tablaContactos, "\"Codigo\", \"NombreCompleto\", \"Correo_e\"", "100, 'supervisor', 'supervisor@localhost'");
        if(resultado)
        {
            pnt.textoLinea("·Tabla " + database.tabla.nombre() + " actualizada.");
        }
        else
        {
            pnt.errTexto("Falló la entrada de nuevos datos a la tabla.");
            codigo = 3;  // puede continuar a pesar del error registrado
        }

        pnt.avLinea();
        pnt.esperar(2);

	// (Baja) Elimina un registro de la tabla Contactos: tabla, condición
        pnt.textoLinea("·Elimina un registro de la tabla:");
        se.print(database.tabla.eliminar(tablaContactos, "\"Codigo\"=100"));

        pnt.avLinea();
        pnt.esperar(2);

        // (Modificación) Modifica datos en la tabla Contactos: tabla, campo id, datos
        resultado = database.tabla.modificar(tablaContactos, "\"Codigo\"=130", "\"Correo_e\"='operador@oracle.com'");
        if(resultado)
        {
            pnt.textoLinea("·Tabla " + database.tabla.nombre() + " modificada.");
        }
        else
        {
            pnt.errTexto("Falló la modificación de los datos en la tabla.");
            codigo = 4;  // puede continuar a pesar del error registrado
        }

        pnt.avLinea();
        pnt.esperar(2);

        pnt.textoLinea("Contenido de la tabla " + database.tabla.nombre());

        // (Consulta) Muestra en pantalla todo el contenido de la tabla Contactos
        resultado = database.tabla.mostrarTodo(tablaContactos);
        if(resultado)
        {
            pnt.textoLinea("·Listado completo efectuado.");
        }
        else
        {
            pnt.errTexto("Falló el listado completo de la tabla.");
            codigo = 5;  // puede continuar a pesar del error registrado
        }

        pnt.avLinea();
        pnt.esperar(3);

        // Ejecuta una sentencia SQL directamente sobre la tabla ordenando sus datos
        // de menor a mayor
        cmd = "select * from " + tablaContactos + " order by "+ campoCodigo + " asc";
        se.println("Datos ordenados por 'Codigo':");
        se.println(database.tabla.ejecutarSQL(cmd));

        // ---------> Cierra la base de datos Agenda <---------
        resultado = database.cerrar();
        if(resultado)
        {
            pnt.textoLinea("·Base de datos cerrada.");
        }
        else
        {
            pnt.errTexto("Falló el cierre de la base de datos.");
            codigo = 6;  // puede continuar a pesar del error registrado
        }

        pnt.textoLinea("Finalizado.");
        return codigo;
    }

    /**
     * Entrada principal a la aplicación.
     *
     * @param args Los argumentos que vienen de la línea de orden (desde la consola de textos).
     * @throws java.io.IOException Lanza una señal causada por operaciones de E/S.
     * @throws java.lang.InterruptedException Lanza una señal de interrupción.
     * @throws java.sql.SQLException Lanza una señal causada por la base de datos SQL.
     */
    public static void main(String[] args) throws IOException, InterruptedException, SQLException
    {
        int codigo = main();
        PruebaDos miAplicacion = new PruebaDos();

        miAplicacion.cout().printf("Devuelve %d.\n", codigo);

        if(codigo != 0)
        {
            miAplicacion.returnOS(codigo);  // retorna al S.O.
        }
    }
}
