--
-- Base de datos para OSQLinuxApp y pruebaDos.
--

--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

--
-- Drop databases (except postgres and template1)
--
DROP DATABASE agenda;

--
-- Databases
--

-- Dumped from database version 14.0
-- Dumped by pg_dump version 14.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Database "agenda" dump
--

--
-- Name: agenda; Type: DATABASE; Schema: -; Owner: postgres
--
CREATE DATABASE agenda WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'es_AR.UTF-8';


ALTER DATABASE agenda OWNER TO postgres;

\connect agenda

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';
SET default_table_access_method = heap;

--
-- Name: Contactos2025; Type: TABLE; Schema: public; Owner: postgres
--
CREATE TABLE public."Contactos2025" (
    "Codigo" integer NOT NULL,
    "NombreCompleto" character varying(80),
    "Correo_e" character varying(80)
);

ALTER TABLE public."Contactos2025" OWNER TO postgres;

--
-- Name: TABLE "Contactos2025"; Type: COMMENT; Schema: public; Owner: postgres
--
COMMENT ON TABLE public."Contactos2025" IS 'Lista de Contactos 2025.';

--
-- Name: contactos; Type: TABLE; Schema: public; Owner: postgres
--
CREATE TABLE public.contactos (
    codigo integer NOT NULL,
    nombrecompleto character varying(64),
    correo_e character varying(320)
);


ALTER TABLE public.contactos OWNER TO postgres;

--
-- Name: TABLE contactos; Type: COMMENT; Schema: public; Owner: postgres
--
COMMENT ON TABLE public.contactos IS 'Lista simple de contactos.';


--
-- Data for Name: Contactos2025; Type: TABLE DATA; Schema: public; Owner: postgres
--
INSERT INTO public."Contactos2025" VALUES (10, 'Supervisor del Sistema.', 'supervisor@localhost.localdomain');
INSERT INTO public."Contactos2025" VALUES (130, 'Operador local del sistema.', 'operador@oracle.com');


--
-- Data for Name: contactos; Type: TABLE DATA; Schema: public; Owner: postgres
--
INSERT INTO public.contactos VALUES (300, 'observador', 'observador@localhost.localdomain');
INSERT INTO public.contactos VALUES (100, 'supervisor', 'supervisor@localhost.localdomain');
INSERT INTO public.contactos VALUES (30, 'fiscalizador', 'fiscalizador@localhost.localdomain');
INSERT INTO public.contactos VALUES (25, 'auditor', 'auditor@localhost.localdomain');
INSERT INTO public.contactos VALUES (20, 'inspector', 'inspector@localhost.localdomain');
INSERT INTO public.contactos VALUES (15, 'interventor', 'interventor@localhost.localdomain');
INSERT INTO public.contactos VALUES (10, 'coordinador', 'coordinador@localhost.localdomain');
INSERT INTO public.contactos VALUES (5, 'administrador', 'administrador@localhost.localdomain');
INSERT INTO public.contactos VALUES (0, '', '');
INSERT INTO public.contactos VALUES (200, 'operador', 'operador@energion.dominiolocal');

--
-- Name: Contactos2025 Contactos2025_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--
ALTER TABLE ONLY public."Contactos2025"
    ADD CONSTRAINT "Contactos2025_pkey" PRIMARY KEY ("Codigo");

--
-- PostgreSQL database dump complete
--
