// Proyecto   : OSQLinuxLib
// Paquete    : libme
// Programa   : Principal.java
// Autor      : Octulio Biletán - Abril de 2025.
// Descripción: Define la clase Libme (LIBrería Martínez Eugenio).
//		Sirve de apoyo, desde la lógica del desarrollo en Java, a la biblioteca OSQLinuxLib.
//		Ejecute en Windows, consola de textos:
//		java --enable-native-access=ALL-UNNAMED -jar .\dist\LIBME.jar
//		Más información, consulte LIBME/doc/doc-técnica.txt
// Ult. cambio: Julio de 2025.
// Licencia   : GNU GPL ver. 3

/* Principal.java
 *
 * Copyright (C) 2025 Eugenio Martínez.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Authors: Eugenio Martínez, https://t.me/octulioBiletan
 */
package libme;

import com.sun.jna.Native;
import com.sun.jna.Pointer;
import pComando.bcComando;

/**
 * Clase Principal. Contiene el método main().
 *
 * @author Octulio Biletan, https://t.me/octulioBiletan
 * @version 1.1
 */
public class Principal
{

    private Libme _libme;
    private Libme.Stdio stdio = null;
    private Libme.Stdlib stdlib = null;
    private Libme.Unistd unistd = null;         // Linux/UNIX
    private Libme.WindowsSDK winsdk = null;     // Windows
    public static Libme.ConsoleIO conio;

    public boolean esWindows = false;
    public boolean esLinux = false;
    public boolean esDesconocido = false;
    public String nombreDesconocido = "x";

    public Principal()
    {
        bcComando so_nombre = new bcComando();
        _libme = new Libme();

        conio = _libme.newConsoleIO();

        stdio = _libme.vincular(stdio);
        stdlib = _libme.vincular(stdlib);

        if (so_nombre.SistemaOperativo().equalsIgnoreCase("linux")) {   // S.O. Linux
            unistd = _libme.vincular(unistd);
            esLinux = true;
        } else if (so_nombre.SistemaOperativo().startsWith("windows")) // S.O. Windows
        {
            winsdk = _libme.vincular(winsdk);
            esWindows = true;
        } else {
            nombreDesconocido = so_nombre.SistemaOperativo();
            System.out.println("[sistema operativo: " + nombreDesconocido + "]");
            esDesconocido = true;
        }
    }

    /**
     * main().
     * @param args Los parámetros que vienen de la línea de comandos.
     */
    public static void main(String[] args) 
    {
        Principal entradaPrincipal = new Principal();

        // Borra la pantalla
        if(entradaPrincipal.esLinux)
        {
            conio.screen.clearscreen();
        }
        else
        {
	    if(entradaPrincipal.esWindows)
	    {
		entradaPrincipal.stdlib.system("cls");
	    }
	}

        // Muestra en pantalla una info. breve sobre esta biblioteca
        entradaPrincipal.stdio.puts("Biblioteca Libme"
                + ", ver. " + entradaPrincipal._libme.version()
                + ", " + entradaPrincipal._libme.fechaConstruccion());
        entradaPrincipal.stdlib.fflush(Pointer.NULL);

        Native.main(args);

        entradaPrincipal.stdio.puts("Conjunto de funciones 'C' soportadas en su S.O.");
        entradaPrincipal.stdlib.fflush(Pointer.NULL);

        System.out.println("\t<stdio.h>   " + (entradaPrincipal.stdio == null ? "x" : "*"));
        System.out.println("\t<stdlib.h>  " + (entradaPrincipal.stdlib == null ? "x" : "*"));
        System.out.println("\t<unistd.h>  " + (entradaPrincipal.unistd == null ? "x" : "*"));
        System.out.println("\t<windows.h> " + (entradaPrincipal.winsdk == null ? "x" : "*"));
        System.out.println("\n*: sí; x: no");

        // Efectúa una pausa de 3 segundos
        if(entradaPrincipal.esLinux)
        {
            entradaPrincipal.unistd.sleep(3);
        }
        else
        {
	    if(entradaPrincipal.esWindows) 
	    {
		entradaPrincipal.winsdk.Sleep(3000);
	    }
	    else
	    {
		System.err.println("Error con sleep(): sistema operativo no reconocido.");
	    }
	}

        // Retorna cero al S.O. anfitrión.
        entradaPrincipal._libme.regresarSO(0);
    }
}
