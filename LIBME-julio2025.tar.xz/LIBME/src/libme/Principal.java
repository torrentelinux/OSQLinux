// Proyecto   : OSQLinuxLib
// Paquete    : libme
// Programa   : Principal.java
// Autor      : Octulio Biletán - Abril de 2025.
// Descripción: Definir la clase Libme (LIBrería Martínez Eugenio).
//              Servir de apoyo, desde la lógica del desarrollo en Java, a la biblioteca OSQLinuxLib.
// Ult. cambio: Julio de 2025.
// Licencia   : GNU GPL ver. 3

/* Principal.java
 *
 * Copyright (C) 2025 Eugenio Martínez.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Authors: Eugenio Martínez, https://t.me/octulioBiletan
 */

package libme;

/**
 * Clase Principal. Contiene el método main().
 * @author Octulio Biletan
 * @version 1.1
 */
public class Principal {
    private Libme _libme;
    private Libme.Stdio stdio = null;
    private Libme.Stdlib stdlib = null;
    private Libme.Unistd unistd = null;
    public static Libme.ConsoleIO conio;

    public Principal() {
        _libme = new Libme();

        conio = _libme.newConsoleIO();

        stdio = _libme.vincular(stdio);
        stdlib = _libme.vincular(stdlib);
        unistd = _libme.vincular(unistd);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Principal entradaPrincipal = new Principal();

        conio.screen.clearscreen();

        entradaPrincipal.stdio.puts("Biblioteca Libme" + 
                                    ", ver. " + entradaPrincipal._libme.version() +
                                    ", " + entradaPrincipal._libme.fechaConstruccion());
        entradaPrincipal.unistd.sleep(3);

        entradaPrincipal._libme.regresarSO(0);
    }
}
