// Proyecto   : OSQLinuxLib
// Paquete    : libme
// Módulo     : Libme.java
// Autor      : Octulio Biletán - Abril de 2025.
// Descripción: Definir la clase Libme (LIBrería Martínez Eugenio).
//              Servir de apoyo, desde la lógica del desarrollo en Java, a la biblioteca OSQLinuxLib.
// Ult. cambio: Julio de 2025.
// Licencia   : GNU GPL ver. 3

/* Libme.java
 *
 * Copyright (C) 2025 Eugenio Martínez.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Authors: Eugenio Martínez, https://t.me/octulioBiletan
 */
package libme;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Platform;
import com.sun.jna.Pointer;
import java.net.InetAddress;
import java.net.UnknownHostException;
import pComando.bcComando;

/** <b>LIBME.JAR</b><br>
 * <p>Clase de propósito general, multiplataforma.<br>
 * Brinda la lógica necesaria que será aplicada en la biblioteca
 * OSQLinuxLib.<br></p>
 *
 * @author Octulio Biletán, https://t.me/octulioBiletan
 * @version 1.1
 */
public class Libme
{

    /**
     * Stdio: standard buffered input/output.<br>
     * Consultar en https://es.wikipedia.org/wiki/Stdio.h
     */
    public interface Stdio extends Library
    {

        /**
         * Consultar 'man 3p putchar'.
         *
         * @param c Un valor de tipo 'int'.
         * @return Un valor de tipo 'int'.
         */
        public int putchar(int c);

        /**
         * Consultar 'man 3p puts'.<br>
         * <b>Ejemplo:</b><br>
         * <pre><code>     int resultado = puts("texto aquí");</code></pre>
         *
         * @param s Una secuencia de caracteres de tipo 'String'.
         * @return Un valor de tipo 'int'.
         */
        public int puts(String s);
    }

    /**
     * Stdlib: standard library definitions.<br>
     * Consultar en https://es.wikipedia.org/wiki/Stdlib.h
     */
    public interface Stdlib extends Library
    {

        /**
         * Consultar 'man 3p putenv'.
         *
         * @param s Una secuencia de caracteres de tipo String. 
         * @return Un valor de tipo 'int'.
         */
        public int putenv(String s);

        /**
         * Consultar 'man 3p system'.<br>
         * <b>Ejemplo:</b><br>
         * <pre><code>     int resultado = system("pwd");</code></pre>
         *
         * @param comando Una secuencia de caracteres de tipo String.
         * @return Un valor de tipo 'int'.
         */
        public int system(String comando);

        /**
         * Consultar 'man 3p fflush'.
         *
         * @param ptr_stream Puntero a fichero de datos o flujo de datos.
         * @return Devuelve cero en caso de éxito o en caso de error EOF.
         */
        public int fflush(Pointer ptr_stream);
    }

    /**
     * Unistd: standard symbolic constants and types (Linux/UNIX).<br>
     * Consultar en https://en.wikipedia.org/wiki/Unistd.h
     */
    public interface Unistd extends Library
    {

        /**
         * Consultar 'man 3p sync'.
         */
        public void sync();

        /**
         * Consultar 'man 3p sleep'.
         *
         * @param seconds Segundos.
         * @return Un valor tipo 'int'.
         */
        public int sleep(int seconds);
    }

    /**
     * WindowsSDK: conjunto de funciones de kernel32.dll<br>
     * Consultar en:<br>
     * (1) https://es.wikipedia.org/wiki/Windows.h<br>
     * (2) https://learn.microsoft.com/es-es/windows/win32/system-services
     */
    public interface WindowsSDK extends Library
    {

        /**
         * Consultar en 'include\windows.h'.<br>
         * Sitio Microsoft: https://learn.microsoft.com/es-es/windows/win32/api/synchapi/nf-synchapi-sleep
         * @param dwMilliseconds Milisegundos.
         */
        public void Sleep(int dwMilliseconds);
    }

    /**
     * Clase ConsoleIO (conio).<br>
     * Contiene la clase Screen.
     */
    public class ConsoleIO {

        /**
         * Clase Screen.
         */
        public class Screen {

            /**
             * Constructor de la clase Screen.
             */
            public Screen() {
            }
           
            /**
             * Borra toda la pantalla de texto y coloca el cursor en la posición 1,1.<br>
             * Consultar en:<br>
             * (a) https://learn.microsoft.com/en-us/windows/console/clearing-the-screen<br>
             * (b) https://learn.microsoft.com/en-us/windows/console/console-virtual-terminal-sequences<br>
             */
            public void clrscr() {
                System.out.print("\033[2J\033[1;1f");
                // Otros métodos a correr en Windows: pwsh -c cls [] cmd /c cls
            }

            /**
             * Es similar a clrscr().
             */
            public void clearscreen() {
                clrscr();
            }

            /**
             * Es similar a clrscr().
             */
            public void cls() {
                clrscr();
            }

            /**
             * Es similar a clrscr().
             */
            public void clear() {
                clrscr();
            }
        }

        /**
         *
         */
        public Screen screen;

        /**
         *
         */
        public ConsoleIO() {
            screen = new Screen();
        }
    }

    /**
     *
     * @return
     */
    public ConsoleIO newConsoleIO() {
        return new ConsoleIO();
    }

    /**
     * Se vincula en tiempo de ejecución con la librería de 'C' del S.O. anfitrión.
     * @param libStdio
     * @return
     */
    public Stdio vincular(Stdio libStdio)
    {
        if(libStdio == null)
        {
            libStdio = (Stdio) Native.load(Platform.C_LIBRARY_NAME, Stdio.class);
            System.out.println("[Vinculado Stdio]");
        }

        return libStdio;
    }

    /**
     * Se vincula en tiempo de ejecución con la librería de 'C' del S.O. anfitrión.
     * @param libStdlib
     * @return
     */
    public Stdlib vincular(Stdlib libStdlib) 
    {
        if(libStdlib == null) 
        {
            libStdlib = (Stdlib) Native.load(Platform.C_LIBRARY_NAME, Stdlib.class);
            System.out.println("[Vinculado Stdlib]");
        }

        return libStdlib;
    }

    /**
     * Se vincula en tiempo de ejecución con la librería de 'C' del S.O. anfitrión.
     * @param libUnistd
     * @return
     */
    public Unistd vincular(Unistd libUnistd) 
    {
        if(libUnistd == null) 
        {
            libUnistd = (Unistd) Native.load(Platform.C_LIBRARY_NAME, Unistd.class);
            System.out.println("[Vinculado Unistd]");
        }

        return libUnistd;
    }

    /**
     * Se vincula en tiempo de ejecución con la librería 'kernel32.dll' del S.O. Windows.
     * @param libWindowssdk
     * @return
     */
    public WindowsSDK vincular(WindowsSDK libWindowssdk) 
    {
        if(libWindowssdk == null) 
        {
            libWindowssdk = (WindowsSDK) Native.load("kernel32", WindowsSDK.class);
            System.out.println("[Vinculado WindowsSDK]");
        }

        return libWindowssdk;
    }

    @SuppressWarnings("unused")
    private final char activa;

    private final String ver;
    private final String fdconstruc;

    /** <b>LIBME.JAR</b><br>
     * Constructor de la clase 'Libme'.<br>
     * Inicializa los datos de la clase.
     */
    public Libme() {
        activa = 1;
        ver = "1.1";
        fdconstruc = "17-Jul-2025";  // dd-mmm-aaaa
    }

    /**
     * Devuelve el nº de versión de la biblioteca LIBME
     * @return El nº de versión como tipo String.
     */
    public String version() 
    {
        return ver;
    }

    /**
     * Devuelve la fecha de construcción de la biblioteca LIBME
     * @return La fecha como tipo String.
     */
    public String fechaConstruccion() 
    {
        return fdconstruc;
    }

    /**
     * Invoca al método <code>System.exit(exit_code)</code> para regresar al S.O.
     *
     * @param exit_code Código de salida que se entrega al S.O.
     */
    public void regresarSO(int exit_code) {
        System.exit(exit_code);
    }

    /**
     * Obtiene el sufijo DNS local principal.<br>
     * Por ejemplo: el nombre simple podría ser 'localhost' y el nombre completo
     * podría ser 'localhost.localdomain',<br>
     * entonces, el resultado obtenido sería 'localdomain'.
     *
     * @return El sufijo DNS local principal del equipo o vacio en caso de no
     * tenerlo.
     * @throws UnknownHostException Lanza una excepción por IP inexistente.
     */
    public String sufijoDNSLocal() throws UnknownHostException {
        String resultado = "";

        // Obtiene el nombre simple del equipo - loopback
        String nombre_simple = InetAddress.getLocalHost().getHostName();

        // Obtiene el nombre completo del equipo - loopback
        String nombre_completo = InetAddress.getLocalHost().getCanonicalHostName();

        if (nombre_simple.equalsIgnoreCase(nombre_completo) == false) {
            if (nombre_completo.startsWith(nombre_simple)) {
                resultado = nombre_completo.substring(nombre_simple.length() + 1);
            } else {
                resultado = "";
            }
        }

        return resultado.toLowerCase();
    }

    /** <b>LIBME.JAR</b><br>
     * <p>Compone una dirección de correo electrónico a partir de las variables:
     * cuenta, equipo y dominio.<br>
     * Se obtiene como resultado: <code>cuenta@equipo.dominio</code><br>
     * Esta dirección no debe superar los límites de 320 caracteres.<br>
     * En caso de superar este límite, se trunca la dirección hasta alcanzar el
     * valor permitido.<br>
     * En caso de que algunas de las variables arriba mencionadas están vacias
     * se le asignará un valor predeterminado.<br>
     * Los sistemas operativos reconocidos son: 'Linux' y 'Windows'.<br>
     * Consultar documento en internet: Simple Mail Transfer Protocol *
     * draft-ietf-emailcore-rfc5321bis-42 *<br>
     * <code>https://datatracker.ietf.org/doc/html/draft-ietf-emailcore-rfc5321bis-42</code></p>
     *
     * @param cuenta El nombre de la cuenta del usuario. La longitud de 'cuenta'
     * no debe superar los 64 caracteres.
     * @param equipo El nombre del equipo. Se sugiere que su longitud total sea
     * de hasta 128 caracteres.
     * @param dominio El nombre de dominio, por ejemplo: <i>com.ar</i>. Se
     * sugiere que su longitud total sea de hasta 127 caracteres.
     * @return La dirección de correo electrónico.
     * @throws java.net.UnknownHostException Lanza una excepción por IP
     * inexistente.
     */
    public String componerCorreoElectronico(String cuenta, String equipo, String dominio) throws UnknownHostException {
        boolean reajuste = false;
        boolean cuenta_modif = false;
        boolean equipo_modif = false;
        String cuenta_local = "cuentalocal";
        String equipo_local = "equipolocal";
        String dominio_local = "dominiolocal";
        String so_usuario = "SINNOMBRE";
        String so_equipo = "SINNOMBRE";
        String correoElectronicoCompleto = "SINASIGNAR";
        bcComando so_nombre = new bcComando();

        if (so_nombre.SistemaOperativo().equalsIgnoreCase("linux")) {   // Vars. de Linux
            so_usuario = "USER";
            so_equipo = "HOSTNAME";
        } else {   // Vars. de Windows
            so_usuario = "USERNAME";
            so_equipo = "COMPUTERNAME";
        }

        if (cuenta.isEmpty() || cuenta == null) {
            String tmp;

            // lee el nombre local de la cuenta en curso que proporciona el S.O.
            tmp = System.getenv(so_usuario);

            if (tmp == null) {
                cuenta_local = "cuentalocal";
            } else if (tmp.isEmpty()) {
                cuenta_local = "cuentalocal";
            } else {
                cuenta_local = tmp;
            }

            if (!equipo.isEmpty()) {
                equipo_local = equipo;
            }

            if (!dominio.isEmpty()) {
                dominio_local = dominio;
            }

            reajuste = true;
            cuenta_modif = true;
        } else {
            // Comprueba la longitud total de 'cuenta' (RFC-5321bis-42).
            if (cuenta.length() > 64) // Trunca hasta 64 caracteres
            {
                cuenta = cuenta.substring(0, 64);
            }
        }

        if (equipo.isEmpty() || equipo == null) {
            String tmp;

            // lee el nombre local del equipo que proporciona el S.O.
            tmp = System.getenv(so_equipo);
            if (tmp == null) {
                equipo_local = "equipolocal";
            } else if (tmp.isEmpty()) {
                equipo_local = "equipolocal";
            } else {
                equipo_local = tmp.toLowerCase();
            }

            if (cuenta_modif == false) {
                cuenta_local = cuenta;
            }

            dominio_local = dominio;
            reajuste = true;
            equipo_modif = true;
        }

        if (dominio.isEmpty() || dominio == null) {
            String tmp = sufijoDNSLocal();

            if (tmp.isEmpty()) {
                dominio_local = "dominiolocal";
            } else {
                dominio_local = tmp;
            }

            if (cuenta_modif == false) {
                cuenta_local = cuenta;
            }

            if (equipo_modif == false) {
                equipo_local = equipo;
            }

            reajuste = true;
        }

        if (reajuste == false) {
            // Comprobar que la longitud total de equipo+dominio no supere los 255 caracteres (RFC-5321bis-42).
            int ndom = equipo.length() + dominio.length();
            correoElectronicoCompleto = cuenta + "@" + equipo + "." + dominio;

            if (ndom > 255) {
                correoElectronicoCompleto = correoElectronicoCompleto.substring(0, 255);
            }
        } else {
            correoElectronicoCompleto = cuenta_local + "@" + equipo_local + "." + dominio_local;
        }

        return correoElectronicoCompleto;
    }
}
